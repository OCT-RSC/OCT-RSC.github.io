# Dataset release contract

The code expects one directory per target-conditioned demonstration, using the
layout documented in `docs/DATA_AND_PREPROCESSING.md`. Raw OCT volumes,
`step_info.json`, target metadata, and generated target volumes are not bundled
in the code repository.

For a lightweight reproducibility artifact, publish two phantom 3-DoF
trajectories matching the installed `mini_phantom_3dof` profile, or publish the
portable prepared point-cloud cache produced from them. The raw option tests
artifact removal and representation construction; the prepared-cache option is
much smaller and tests dataset assembly, model execution, training, validation,
and checkpoint loading. Ideally release both as separate versioned assets.

The two source trajectory directories occupy approximately 1.44 GB before
filtering. The raw packager excludes RGB images and unrelated session files;
the OCT arrays remain the dominant size. The prepared point-cloud artifact is
much smaller but cannot independently test OCT cleanup or tissue extraction.

After unpacking the prepared artifact, a user can immediately exercise the
model contract or train the mini example without editing a manifest:

```bash
oct-policy smoke \
  --prepared /path/to/mini_point_cloud_prepared \
  --experiment phantom_point_cloud_with_residual_bc

oct-policy train \
  --prepared /path/to/mini_point_cloud_prepared \
  --experiment phantom_point_cloud_with_residual_bc \
  --output outputs/mini_point_bc
```

Before distributing either artifact, confirm participant/institutional data
policy, dataset terms, and the checkpoint license. The code repository should
record the asset URL and SHA-256 digest after approval rather than embedding a
private filesystem path.

After distribution is approved, create the path-sanitized raw artifact with:

```bash
python tools/package_mini_raw.py \
  --data-root /path/to/official_data \
  --data-profile mini_phantom_3dof \
  --material phantom \
  --output release_assets/mini_phantom_3dof_raw \
  --archive release_assets/mini_phantom_3dof_raw.tar.gz
```

The packager copies only OCT volumes, fixed targets, target sidecars, and the
action/pose records needed by the learner. It excludes RGB, GUI recordings,
robot-session extras, and machine-specific absolute paths, then runs the same
dataset audit against the packaged tree.
