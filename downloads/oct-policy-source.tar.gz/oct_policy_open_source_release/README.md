# OCT Tissue Policy

This repository contains the training, evaluation, and closed-loop inference
code used for the real-system OCT rollout policies. It supports:

- 3-DoF and 6-DoF demonstrations;
- full-volume, tissue-only sparse-volume, and point-cloud observations;
- optional target-minus-observation residual conditioning;
- deterministic action-chunk behavior cloning and clean-action (`x0`) diffusion;
- the same `reset(target, initial_pose)` / `step(scan, current_pose)` interface
  used by the scan–policy–action system.

The release intentionally excludes robot drivers, the GUI, cluster submission
files, private datasets, generated caches, and historical prototypes. The
training and rollout code retains the package and parameter names used by the
current unified checkpoints. Checkpoints may be distributed separately after
their release terms are approved.

## Code layout

```text
src/oct_policy/
  api.py                       Small public rollout API
  cli.py                       User-facing command line
  workflow.py                  Prepare/train/validate orchestration
  inference.py                 Saved-scan rollout inference
  comparison.py                Released-vs-retrained checkpoint comparison
  checkpoint.py                Compact EMA checkpoint export
  experiments.py               Bundled experiment discovery
  data_profiles/*.json         Exact mini and official dataset selections
  matrices/*.json              Paper experiment groups
src/tissue_ai_ui_bundle/
  oct_volume_processing.py     OCT surface and artifact processing
  physical_policy/
    volume_preprocessing.py    Full-volume coordinate/intensity convention
    real_data.py               Saved trajectory and action conventions
    models.py                  Shared dense encoder and diffusion blocks
  policy_experiments/
    config.py                  Reproducible experiment configuration
    representations.py         Full, sparse-tissue, and point-cloud inputs
    data.py                    Audit, split, cache, and PyTorch dataset
    models.py                  Representation encoders and policy heads
    engine.py                  Training, validation, and checkpointing
    interface.py               Online closed-loop policy interface
scripts/
  reproduce.py                 Compatibility wrapper for the public CLI
  prepare_data.py              Raw demonstrations -> split and cache
  train.py                     Prepared cache -> checkpoint
  evaluate.py                  Checkpoint -> frozen-validation metrics
  rollout.py                   Sequential scans -> action chunks
  smoke_test.py                One cached sample -> contract/load/inference check
tools/
  package_mini_cache.py        Sanitize and archive a portable prepared cache
  package_mini_raw.py          Create a path-sanitized raw mini dataset
  verify_release.py            Source and checkpoint compatibility audit
```

The longer internal namespace is retained so existing checkpoints and system
integration code continue to load. New applications can use the short public
API:

```python
from oct_policy import load_policy

policy = load_policy("checkpoint_best.pt", device="cuda")
policy.reset(target_volume, initial_tooltip_pose_4x4)
result = policy.step(new_oct_scan, current_tooltip_pose_4x4)
robot_action = result["action_6dof_mm_deg"]
```

For saved scans, the same path is available without writing Python:

```bash
oct-policy infer \
  --checkpoint checkpoint_best.pt \
  --rollout examples/rollout.example.json \
  --output outputs/predictions.json \
  --device cuda
```

This command only predicts actions; it never sends commands to a robot.

## Installation

```bash
python -m pip install -e ".[test]"
oct-policy list
```

The tissue-only sparse CNN uses ordinary PyTorch operations and does not require
MinkowskiEngine. This release supports the current native-PyTorch tissue-only
checkpoints; superseded MinkowskiEngine checkpoints are intentionally outside
the public compatibility contract.

## Reproducing one experiment

Choose an installed experiment and data profile by name. Run
`oct-policy list` to see the available choices; explicit JSON paths are also
accepted for custom experiments and data selections.

The public command runs raw-data validation, preprocessing, the frozen split,
training, final validation, and offline inference in one resumable workflow:

```bash
oct-policy reproduce \
  --data-root /path/to/official_data \
  --data-profile official_6dof \
  --experiment phantom_point_cloud_with_residual_diffusion \
  --output outputs/phantom_6dof_point_diffusion
```

The output directory is self-describing:

```text
prepared/                  audit, frozen split, and representation cache
training/                  history and best/last checkpoints
checkpoint_inference.pt    compact EMA checkpoint ready for deployment
validation.json            frozen-validation metrics
offline_predictions.json   per-state predicted and recorded action chunks
reproduction.json          compact paths, hashes, and final summary
```

Every stage can also be run separately. The prepared directory replaces the
old requirement to copy a generated manifest path by hand:

```bash
oct-policy prepare \
  --data-root /path/to/official_data \
  --data-profile official_6dof \
  --experiment phantom_point_cloud_with_residual_diffusion \
  --output prepared/phantom_6dof_point

oct-policy train \
  --prepared prepared/phantom_6dof_point \
  --experiment phantom_point_cloud_with_residual_diffusion \
  --output outputs/phantom_point_diffusion

oct-policy evaluate \
  --prepared prepared/phantom_6dof_point \
  --checkpoint outputs/phantom_point_diffusion/checkpoint_best.pt \
  --output outputs/phantom_point_diffusion/validation.json
```

Training resumes `checkpoint_last.pt` by default; pass `--fresh` to disable
resume.

`reproduce` and `matrix` export compact inference checkpoints automatically.
When stages are run separately, the same export is available explicitly:

```bash
oct-policy export-checkpoint \
  --input outputs/phantom_point_diffusion/checkpoint_best.pt \
  --output checkpoints/phantom_point_diffusion.pt
```

The export retains the exact EMA weights and model configuration, verifies a
strict state-dict load, records the source checkpoint SHA-256, and removes
optimizer, scheduler, RNG, and training-history state.

Before a long run, one command can verify the prepared cache, model input
contract, optional checkpoint load, and one predicted action chunk:

```bash
oct-policy smoke \
  --prepared prepared/phantom_6dof_point \
  --checkpoint checkpoints/phantom_point_diffusion.pt \
  --verify-all-cache-files
```

## Reproducing the paper matrix

The phantom paper matrix contains the twelve combinations of three input
representations, residual on/off, and deterministic/diffusion action heads.
Run it once for each action regime. Representation caches are shared across
heads and residual choices instead of being rebuilt twelve times.

```bash
oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_3dof \
  --matrix phantom_paper \
  --output outputs/phantom_3dof

oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_6dof \
  --matrix phantom_paper \
  --output outputs/phantom_6dof
```

`matrix_results.json` is updated after each finished experiment, so an
interrupted run can resume without losing completed results.

## Small-data end-to-end check

The installed `mini_phantom_3dof` profile selects two real demonstrations
from the standard data layout. One trajectory becomes training data and one becomes
validation data, which is sufficient to exercise discovery, artifact cleanup,
representation construction, split freezing, cache hashing, model input
assembly, and inference without launching the full experiment matrix.

```bash
oct-policy reproduce \
  --data-root /path/to/official_data \
  --data-profile mini_phantom_3dof \
  --experiment phantom_point_cloud_with_residual_bc \
  --output outputs/mini_point_bc
```

The prepared manifest stores representation files relative to its own
directory, so the mini cache can be archived and moved to another machine.
Raw OCT examples are not bundled until dataset-release approval is complete.
See [DATASET.md](DATASET.md) for the proposed two-trajectory release artifact.
Before distributing a prepared cache, remove machine-specific provenance with:

```bash
python tools/package_mini_cache.py \
  --prepared outputs/mini_point_bc/prepared \
  --output release_assets/mini_point_bc \
  --archive release_assets/mini_point_bc.tar.gz
```

## Experiment invariants

- Observation history: 3 states, left-padded with the first real state.
- Predicted action horizon: 8 local 6-DoF deltas.
- Executed horizon: the first predicted action only.
- Translation unit: millimetres; rotation unit: Euler-XYZ degrees.
- 3-DoF runs use the same six-component action tensor with zero rotational
  labels; 6-DoF runs contain both translation and rotation.
- Target inputs are derived from the saved `target_volume.npy`.
- Short action tails are masked out of the loss; padded zero storage is not a
  stop-action label.
- Checkpoint selection uses validation first-action normalized MSE, averaged
  per trajectory and then across trajectories.
- Validation and rollout use EMA weights.

See [data and preprocessing](docs/DATA_AND_PREPROCESSING.md),
[models and training](docs/MODELS_AND_TRAINING.md), and the
[consistency audit](docs/CONSISTENCY_AUDIT.md) for the exact contracts. The
[paper reproduction guide](docs/REPRODUCING_PAPER.md) separates the fast
pipeline check from full-data training and physical rollout evaluation. The
[verified environment](docs/ENVIRONMENT.md) records the software and GPU stack
used for end-to-end testing. The
[release verification](docs/VERIFICATION.md) explains source, checkpoint, and
executable compatibility checks. `tools/verify_release.py` classifies every
provided `.pt` by embedded schema and performs strict state-dict loading; it
does not infer compatibility from a filename.
The [GitHub integration note](docs/GITHUB_INTEGRATION.md) records the boundary
between the public policy package and the hardware/UI repository.

## Before public release

The project owner must add the institution-approved open-source license and any
required dataset/checkpoint usage terms. No license is selected automatically
by this code-only cleanup.
