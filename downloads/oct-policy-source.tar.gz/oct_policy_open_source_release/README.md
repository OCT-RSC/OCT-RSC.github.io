# OCT shape-control policies

Training and inference code for target-conditioned OCT tissue deformation control.
Three inputs are supported: full volume, tissue-only sparse volume, and point cloud.
Each can use an Explicit or Diffusion policy, with or without residual conditioning.

## Setup

Use Python 3.10 or newer and install PyTorch for your CPU or CUDA version, then:

```bash
pip install -r requirements.txt
```

Tissue-only uses native PyTorch sparse operations. MinkowskiEngine is not required.

## Train and evaluate

Run commands from this directory. For example, train Point-cloud Explicit with residuals:

```bash
python prepare_data.py --data-root /path/to/data \
  --data-profile configs/data/official_3dof.json \
  --config configs/phantom_point_residual_bc.json --output prepared/point

python train_policy.py --prepared prepared/point \
  --config configs/phantom_point_residual_bc.json --output outputs/point

python evaluate_policy.py --prepared prepared/point \
  --checkpoint outputs/point/checkpoint_best.pt --output outputs/point/validation.json \
  --predictions outputs/point/predictions.json
```

Choose another file in `configs/` to change representation, decoder, or residuals.
Use `configs/data/official_6dof.json` for directional demonstrations.
Data profiles select the appropriate dataset folders; omit `--data-profile` for your
own dataset. Split assignment is trajectory-level, approximately 80/20 within each
target condition, with seed 42. Provide at least two demonstrations per condition.

Training uses AdamW, EMA weights, and a maximum of 100 epochs. The best checkpoint
is selected by validation first-action normalized MSE, averaged within each
trajectory and then across trajectories. Training resumes automatically; use
`--fresh` with a new output directory to start over.

For a quick run, use the prepared Point-cloud mini dataset and add `--epochs 1`
to the training command. This tests the workflow; it is not a paper-performance run.

## Inference

The checkpoint selects its own architecture and preprocessing settings.

```bash
python run_policy.py --trajectory /path/to/traj_1 \
  --checkpoint outputs/point/checkpoint_best.pt --output predictions.json --device cuda
```

This replays recorded observations, not robot motion. To use live scans:

```python
from oct_policy import load_policy

policy = load_policy("checkpoint_best.pt", device="cuda")
policy.reset("/path/to/traj_1/predeform/target_volume.npy", initial_tooltip_pose)
result = policy.step("/path/to/current/ascans.npy", current_tooltip_pose)
action = result["action_6dof_mm_deg"]
```

Tooltip poses are 4-by-4 transforms with translations in metres. The pose input
uses translation in millimetres and a rotation vector in degrees, divided by 20.
The model predicts eight six-dimensional actions; the interface returns the first
action in millimetres and Euler-xyz degrees after multiplying normalized actions by 2.
Only load checkpoints from trusted sources.

## Data format

Each demonstration contains a fixed target and one OCT scan per recorded state:

```text
condition/traj_1/
  predeform/
    ascans.npy
    target_volume.npy
    target_selection.json
    targets/
      pre_surface_yx_vox.npy
      .../gaussian_displacement_yx_mm.npy
  1/ascans.npy
  1/step_info.json
  2/ascans.npy
  2/step_info.json
  ...
```

Raw OCT arrays are signed int8 in HWD order, `[256,256,768]`, optionally with outer
singleton dimensions. Target metadata records material, spacing and the selected
displacement field. Each `step_info.json` records `tooltip_transform_4x4` and local
commands under `inputs_6dof_mm_deg`. Do not omit the predeformation metadata required
for artifact removal. A saved target is used unchanged throughout a trajectory.

Full-volume inputs are normalized `[256,256,256]` DHW arrays. Tissue-only retains
occupied voxel coordinates `[N,3]` and intensities `[N,1]` on a `[72,128,128]` lattice.
Point-cloud inputs contain 1,024 scanner-fixed normalized XYZ coordinates. All
representations are constructed from the measured OCT volume and saved target.

## Code

`oct_policy/` contains preprocessing, representations, models, training and inference.
The four root scripts are the entry points; `configs/` contains the paper settings.

Run the small functional tests with `python -m unittest discover -s tests`.
