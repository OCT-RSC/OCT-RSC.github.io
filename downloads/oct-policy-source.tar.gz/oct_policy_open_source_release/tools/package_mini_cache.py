#!/usr/bin/env python3
from __future__ import annotations

"""Create a path-sanitized, relocatable prepared-cache release artifact."""

import argparse
import hashlib
import json
import shutil
import tarfile
from pathlib import Path


def canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def payload_digest(value: dict, excluded_key: str) -> str:
    payload = {key: item for key, item in value.items() if key != excluded_key}
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--prepared",
        type=Path,
        help="Prepared directory produced by oct-policy prepare/reproduce.",
    )
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--split", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    return parser.parse_args()


def source_paths(args: argparse.Namespace) -> tuple[Path, Path, dict]:
    if args.prepared is not None:
        if args.manifest is not None or args.split is not None:
            raise ValueError("Use --prepared or --manifest/--split, not both")
        prepared_root = args.prepared.resolve()
        metadata = json.loads(
            (prepared_root / "prepared.json").read_text(encoding="utf-8")
        )

        def resolve(key: str) -> Path:
            value = Path(metadata[key])
            return value if value.is_absolute() else prepared_root / value

        return resolve("manifest"), resolve("split"), metadata
    if args.manifest is None or args.split is None:
        raise ValueError("Provide --prepared or both --manifest and --split")
    return args.manifest.resolve(), args.split.resolve(), {}


def assert_relative_cache_paths(manifest: dict) -> None:
    for trajectory in manifest["trajectories"]:
        paths = [*trajectory["observations"], trajectory["target"]]
        absolute = [path for path in paths if Path(path).is_absolute()]
        if absolute:
            raise ValueError(
                "Mini-cache packaging requires a v2 manifest with relative cache "
                f"paths; found absolute entries such as {absolute[0]}"
            )


def main() -> None:
    args = parse_args()
    manifest_path, split_path, source_metadata = source_paths(args)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {output}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    split = json.loads(split_path.read_text(encoding="utf-8"))
    assert_relative_cache_paths(manifest)
    cache_name = manifest_path.parent.name
    destination_manifest_dir = output / "cache" / cache_name
    shutil.copytree(manifest_path.parent, destination_manifest_dir)

    split["data_root"] = "EXTERNAL_DATASET_NOT_INCLUDED"
    split["split_sha256"] = payload_digest(split, "split_sha256")
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "split.json", split)

    manifest["data_root"] = "EXTERNAL_DATASET_NOT_INCLUDED"
    manifest["split"] = "../../split.json"
    manifest["split_sha256"] = split["split_sha256"]
    manifest["cache_sha256"] = payload_digest(manifest, "cache_sha256")
    packaged_manifest = destination_manifest_dir / "manifest.json"
    write_json(packaged_manifest, manifest)
    write_json(
        output / "audit.json",
        {
            "schema": "oct_policy_packaged_cache_audit_v1",
            "trajectory_count": len(manifest["trajectories"]),
            "error_count": 0,
            "note": (
                "Raw source paths are intentionally excluded from this "
                "prepared-cache artifact."
            ),
        },
    )
    write_json(
        output / "prepared.json",
        {
            "schema": "oct_policy_prepared_data_v1",
            "data_profile": source_metadata.get("data_profile", "packaged_cache"),
            "data_profile_digest": source_metadata.get("data_profile_digest"),
            "action_regime": source_metadata.get("action_regime"),
            "task": source_metadata.get("task"),
            "experiment": source_metadata.get("experiment"),
            "material": manifest["material"],
            "representation": manifest["representation"],
            "config_digest": source_metadata.get("config_digest"),
            "split_sha256": split["split_sha256"],
            "cache_sha256": manifest["cache_sha256"],
            "audit": "audit.json",
            "manifest": f"cache/{cache_name}/manifest.json",
            "split": "split.json",
            "train_trajectories": len(split["train"]),
            "validation_trajectories": len(split["validation"]),
            "actions": sum(
                len(trajectory["actions"])
                for trajectory in manifest["trajectories"]
            ),
            "observations_including_initial": sum(
                len(trajectory["observations"])
                for trajectory in manifest["trajectories"]
            ),
        },
    )

    archive = args.archive.resolve() if args.archive else None
    if archive is not None:
        archive.parent.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive, "w:gz") as stream:
            stream.add(output, arcname=output.name)
    print(
        json.dumps(
            {
                "output": str(output),
                "manifest": str(packaged_manifest),
                "archive": str(archive) if archive else None,
                "cache_sha256": manifest["cache_sha256"],
                "split_sha256": split["split_sha256"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
