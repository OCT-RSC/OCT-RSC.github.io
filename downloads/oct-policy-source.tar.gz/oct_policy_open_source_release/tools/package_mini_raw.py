#!/usr/bin/env python3
from __future__ import annotations

"""Create a path-sanitized raw mini dataset for preprocessing reproduction."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import tarfile

from tissue_ai_ui_bundle.physical_policy.real_data import numeric_steps
from tissue_ai_ui_bundle.policy_experiments.config import write_json_atomic
from tissue_ai_ui_bundle.policy_experiments.data import (
    audit_dataset,
    discover_trajectories,
    trajectory_id,
)
from oct_policy.experiments import resolve_data_profile


WINDOWS_ABSOLUTE = re.compile(r"^[A-Za-z]:[\\/]")


def portable_absolute_path(value: str) -> str:
    """Keep useful paths below ``predeform`` and discard machine prefixes."""

    parsed = (
        PureWindowsPath(value)
        if WINDOWS_ABSOLUTE.match(value)
        else PurePosixPath(value)
    )
    parts = parsed.parts
    names = [part.lower() for part in parts]
    if "predeform" in names:
        index = names.index("predeform")
        suffix = parts[index + 1 :]
        if suffix:
            return PurePosixPath(*suffix).as_posix()
    return parsed.name


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--data-profile", required=True)
    parser.add_argument("--material", choices=("phantom", "exvivo"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sanitize_json(value):
    """Remove machine-specific absolute paths while preserving other values."""

    if isinstance(value, dict):
        return {key: sanitize_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize_json(item) for item in value]
    if isinstance(value, str):
        path = Path(value)
        if path.is_absolute() or WINDOWS_ABSOLUTE.match(value):
            return portable_absolute_path(value)
    return value


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix.lower() == ".json":
        value = json.loads(source.read_text(encoding="utf-8"))
        write_json_atomic(destination, sanitize_json(value))
    else:
        shutil.copy2(source, destination)


def target_volume(trajectory: Path) -> Path:
    for candidate in (
        trajectory / "predeform" / "target_volume.npy",
        trajectory / "target_volume.npy",
    ):
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"No target_volume.npy in {trajectory}")


def required_files(trajectory: Path) -> list[Path]:
    files = [trajectory / "predeform" / "ascans.npy", target_volume(trajectory)]
    selection = trajectory / "predeform" / "target_selection.json"
    files.append(selection)
    targets = trajectory / "predeform" / "targets"
    if targets.is_dir():
        files.extend(
            path
            for path in targets.rglob("*")
            if path.is_file() and path.suffix.lower() in (".json", ".npy")
        )
    for step in numeric_steps(trajectory):
        files.extend((step / "ascans.npy", step / "step_info.json"))
    missing = [path for path in files if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Required demonstration files are missing: {missing}")
    return sorted(set(files))


def main() -> None:
    args = parse_args()
    data_root = args.data_root.expanduser().resolve()
    profile_path = resolve_data_profile(args.data_profile)
    output = args.output.expanduser().resolve()
    if output.exists():
        if not output.is_dir() or any(output.iterdir()):
            raise FileExistsError(f"Output directory is not empty: {output}")
    output.mkdir(parents=True, exist_ok=True)

    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    if profile.get("schema") != "oct_policy_data_profile_v1":
        raise ValueError("Unsupported data-profile schema")
    prefixes = profile["include_prefixes"][args.material]
    trajectories = discover_trajectories(
        data_root, material=args.material, include_prefixes=prefixes,
    )
    if not trajectories:
        raise RuntimeError("The selected data profile contains no trajectories")

    records = []
    for trajectory in trajectories:
        identifier = trajectory_id(trajectory, data_root)
        copied = []
        for source in required_files(trajectory):
            relative = source.relative_to(data_root)
            destination = output / relative
            copy_file(source, destination)
            copied.append(
                {
                    "path": relative.as_posix(),
                    "bytes": destination.stat().st_size,
                    "sha256": sha256(destination),
                }
            )
        records.append({"trajectory": identifier, "files": copied})

    audit = audit_dataset(output, include_prefixes=prefixes)
    if audit["error_count"] or audit["trajectory_count"] != len(trajectories):
        raise RuntimeError(f"Packaged mini dataset failed audit: {audit['errors']}")
    manifest = {
        "schema": "oct_policy_raw_mini_dataset_v1",
        "profile": profile["name"],
        "material": args.material,
        "trajectory_count": len(trajectories),
        "records": records,
        "audit": {
            "trajectory_count": audit["trajectory_count"],
            "error_count": audit["error_count"],
        },
    }
    write_json_atomic(output / "MINI_DATASET_MANIFEST.json", manifest)

    if args.archive is not None:
        archive = args.archive.expanduser().resolve()
        archive.parent.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive, "w:gz") as stream:
            stream.add(output, arcname=output.name)
        print(
            json.dumps({"archive": str(archive), "sha256": sha256(archive)}, indent=2)
        )
    else:
        print(
            json.dumps(
                {"output": str(output), "trajectories": len(trajectories)}, indent=2
            )
        )


if __name__ == "__main__":
    main()
