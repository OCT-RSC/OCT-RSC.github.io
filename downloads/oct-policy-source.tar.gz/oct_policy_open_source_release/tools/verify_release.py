#!/usr/bin/env python3
from __future__ import annotations

"""Audit source parity and classify checkpoint compatibility without guessing."""

import argparse
import hashlib
import json
from pathlib import Path

from tissue_ai_ui_bundle.policy_experiments.config import (
    EXPERIMENT_SCHEMA,
    torch_load,
    write_json_atomic,
)
from tissue_ai_ui_bundle.policy_experiments.models import build_policy


INFERENCE_FILES = (
    "oct_volume_processing.py",
    "physical_policy/models.py",
    "physical_policy/real_data.py",
    "physical_policy/volume_preprocessing.py",
    "policy_experiments/interface.py",
    "policy_experiments/models.py",
    "policy_experiments/representations.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reference-source",
        type=Path,
        help="Optional tissue_ai_ui_bundle directory used for byte comparison.",
    )
    parser.add_argument("--checkpoint", type=Path, action="append", default=[])
    parser.add_argument(
        "--checkpoint-dir",
        type=Path,
        action="append",
        default=[],
        help="Recursively audit every .pt file in this directory.",
    )
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def source_report(reference_source: Path | None) -> dict:
    if reference_source is None:
        return {"reference_source": None, "files": {}}
    release_source = Path(__file__).parents[1] / "src/tissue_ai_ui_bundle"
    reference_source = reference_source.resolve()
    files = {}
    for relative in INFERENCE_FILES:
        released = release_source / relative
        reference = reference_source / relative
        if not reference.is_file():
            files[relative] = {
                "released_sha256": sha256(released),
                "reference_sha256": None,
                "identical": False,
                "error": "reference file is missing",
            }
            continue
        released_hash = sha256(released)
        reference_hash = sha256(reference)
        files[relative] = {
            "released_sha256": released_hash,
            "reference_sha256": reference_hash,
            "identical": released_hash == reference_hash,
        }
    return {
        "reference_source": str(reference_source),
        "files": files,
        "all_inference_files_identical": all(
            item["identical"] for item in files.values()
        ),
    }


def checkpoint_report(path: Path) -> dict:
    path = path.resolve()
    item = {
        "name": path.name,
        "sha256": sha256(path),
        "status": "unsupported_or_invalid",
        "strict_load": False,
    }
    try:
        saved = torch_load(path, map_location="cpu")
        if not isinstance(saved, dict):
            raise TypeError(f"checkpoint root is {type(saved).__name__}, not dict")
        item["schema"] = saved.get("schema")
        if saved.get("schema") != EXPERIMENT_SCHEMA:
            item["status"] = "legacy_schema"
            return item
        config = saved["config"]
        weights_name = saved.get("evaluation_weights", "ema")
        weights_key = "model_ema" if weights_name == "ema" else "model_raw"
        if weights_key not in saved:
            raise KeyError(f"checkpoint does not contain {weights_key}")
        policy = build_policy(config)
        incompatible = policy.load_state_dict(saved[weights_key], strict=True)
        item.update(
            {
                "status": "compatible",
                "strict_load": not incompatible.missing_keys
                and not incompatible.unexpected_keys,
                "weights": weights_key,
                "export_format": saved.get("export_format", "full_training_state"),
                "experiment": config.get("experiment_name"),
                "material": config.get("material"),
                "representation": config.get("representation"),
                "residual": config.get("use_residual"),
                "head": config.get("head"),
                "sparse_backend": config.get("sparse_backend"),
                "parameter_count": sum(
                    parameter.numel() for parameter in policy.parameters()
                ),
            }
        )
    except Exception as error:
        item["error"] = f"{type(error).__name__}: {error}"
    return item


def main() -> None:
    args = parse_args()
    checkpoint_paths = {path.resolve() for path in args.checkpoint}
    for directory in args.checkpoint_dir:
        checkpoint_paths.update(directory.resolve().rglob("*.pt"))
    checkpoints = [checkpoint_report(path) for path in sorted(checkpoint_paths)]
    compatible = [item for item in checkpoints if item["status"] == "compatible"]
    report = {
        "source": source_report(args.reference_source),
        "checkpoint_count": len(checkpoints),
        "compatible_count": len(compatible),
        "legacy_or_invalid_count": len(checkpoints) - len(compatible),
        "all_unified_checkpoints_load_strictly": all(
            item["strict_load"] for item in compatible
        ),
        "checkpoints": checkpoints,
    }
    write_json_atomic(args.output, report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
