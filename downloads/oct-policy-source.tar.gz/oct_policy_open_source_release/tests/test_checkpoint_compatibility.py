from __future__ import annotations

import os
from pathlib import Path

import pytest

from tissue_ai_ui_bundle.policy_experiments.config import torch_load
from tissue_ai_ui_bundle.policy_experiments.models import build_policy


@pytest.mark.skipif(
    "OCT_POLICY_CHECKPOINT" not in os.environ,
    reason="Set OCT_POLICY_CHECKPOINT to test a private checkpoint",
)
def test_checkpoint_loads_strictly() -> None:
    checkpoint = Path(os.environ["OCT_POLICY_CHECKPOINT"])
    saved = torch_load(checkpoint, map_location="cpu")
    policy = build_policy(saved["config"])
    result = policy.load_state_dict(saved["model_ema"], strict=True)
    assert not result.missing_keys
    assert not result.unexpected_keys

