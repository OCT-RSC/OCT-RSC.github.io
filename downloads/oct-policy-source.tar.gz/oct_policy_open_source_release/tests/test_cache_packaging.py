from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

from oct_policy.workflow import PreparedDataset
from tissue_ai_ui_bundle.policy_experiments.data import (
    validate_cache_manifest,
    validate_split_payload,
)


ROOT = Path(__file__).parents[1]


def test_packaged_cache_opens_with_public_workflow(tmp_path: Path) -> None:
    source = tmp_path / "source"
    manifest_dir = source / "cache" / "point_cache"
    manifest_dir.mkdir(parents=True)
    (source / "audit.json").write_text("{}", encoding="utf-8")
    split = {
        "schema": "trajectory_split_v1",
        "data_root": "/private/source",
        "material": "phantom",
        "split_seed": 42,
        "validation_fraction": 0.2,
        "include_prefixes": [],
        "train": ["train"],
        "validation": ["validation"],
        "groups": {},
        "split_sha256": "replaced_by_packager",
    }
    (source / "split.json").write_text(json.dumps(split), encoding="utf-8")
    manifest = {
        "schema": "oct_policy_representation_cache_v2",
        "data_root": "/private/source",
        "split": "/private/source/split.json",
        "split_sha256": "replaced_by_packager",
        "material": "phantom",
        "representation": "point_cloud",
        "trajectories": [],
        "cache_sha256": "replaced_by_packager",
    }
    (manifest_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (source / "prepared.json").write_text(
        json.dumps(
            {
                "schema": "oct_policy_prepared_data_v1",
                "data_profile": "mini",
                "manifest": "cache/point_cache/manifest.json",
                "split": "split.json",
                "audit": "audit.json",
            }
        ),
        encoding="utf-8",
    )

    packaged = tmp_path / "packaged"
    subprocess.run(
        [
            sys.executable,
            str(ROOT / "tools/package_mini_cache.py"),
            "--prepared",
            str(source),
            "--output",
            str(packaged),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    prepared = PreparedDataset.open(packaged)
    packaged_split = json.loads(prepared.split.read_text(encoding="utf-8"))
    packaged_manifest = json.loads(prepared.manifest.read_text(encoding="utf-8"))
    validate_split_payload(packaged_split)
    validate_cache_manifest(packaged_manifest)
    assert packaged_split["data_root"] == "EXTERNAL_DATASET_NOT_INCLUDED"
    assert packaged_manifest["data_root"] == "EXTERNAL_DATASET_NOT_INCLUDED"
