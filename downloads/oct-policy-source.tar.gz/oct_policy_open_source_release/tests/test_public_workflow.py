from __future__ import annotations

import json
from pathlib import Path

from oct_policy.experiments import (
    available_matrices,
    available_experiments,
    describe_experiments,
    resolve_experiment,
    resolve_matrix,
)
from oct_policy.workflow import MATRIX_SCHEMA, PREPARED_DATA_SCHEMA, PreparedDataset
from tissue_ai_ui_bundle.policy_experiments.config import CACHE_SCHEMA
from tissue_ai_ui_bundle.policy_experiments.data import (
    cache_manifest_digest,
    split_digest,
)


def test_bundled_experiments_resolve_by_name() -> None:
    names = available_experiments()
    assert "phantom_point_cloud_with_residual_bc" in names
    assert "exvivo_full_volume_with_residual_diffusion" in names
    assert resolve_experiment("phantom_point_cloud_with_residual_bc").is_file()
    point_bc = {item["name"]: item for item in describe_experiments()}[
        "phantom_point_cloud_with_residual_bc"
    ]
    assert point_bc == {
        "name": "phantom_point_cloud_with_residual_bc",
        "material": "phantom",
        "representation": "point_cloud",
        "residual": True,
        "head": "deterministic_bc",
    }


def test_prepared_metadata_uses_relocatable_paths(tmp_path: Path) -> None:
    original = tmp_path / "original"
    original.mkdir()
    (original / "cache").mkdir()
    (original / "audit.json").write_text("{}", encoding="utf-8")
    split = {
        "schema": "trajectory_split_v1",
        "material": "phantom",
        "train": [],
        "validation": [],
    }
    split["split_sha256"] = split_digest(split)
    (original / "split.json").write_text(json.dumps(split), encoding="utf-8")
    manifest = {
        "schema": CACHE_SCHEMA,
        "material": "phantom",
        "representation": "point_cloud",
        "split_sha256": split["split_sha256"],
        "trajectories": [],
    }
    manifest["cache_sha256"] = cache_manifest_digest(manifest)
    (original / "cache/manifest.json").write_text(
        json.dumps(manifest), encoding="utf-8"
    )
    (original / "prepared.json").write_text(
        json.dumps(
            {
                "schema": PREPARED_DATA_SCHEMA,
                "audit": "audit.json",
                "split": "split.json",
                "manifest": "cache/manifest.json",
            }
        ),
        encoding="utf-8",
    )
    moved = tmp_path / "moved"
    original.rename(moved)

    prepared = PreparedDataset.open(moved)
    assert prepared.manifest == moved / "cache" / "manifest.json"


def test_phantom_matrix_contains_each_model_choice_once() -> None:
    assert set(available_matrices()) == {
        "exvivo_3dof",
        "exvivo_6dof",
        "phantom_paper",
    }
    matrix = json.loads(resolve_matrix("phantom_paper").read_text(encoding="utf-8"))
    assert matrix["schema"] == MATRIX_SCHEMA
    assert len(matrix["experiments"]) == 12
    assert len(set(matrix["experiments"])) == 12
    assert set(matrix["experiments"]).issubset(available_experiments())


def test_exvivo_matrices_cover_both_action_regimes() -> None:
    three = json.loads(resolve_matrix("exvivo_3dof").read_text(encoding="utf-8"))
    six = json.loads(resolve_matrix("exvivo_6dof").read_text(encoding="utf-8"))
    assert three["schema"] == six["schema"] == MATRIX_SCHEMA
    assert len(three["experiments"]) == len(six["experiments"]) == 2
    assert "exvivo_point_cloud_with_residual_bc_3dof" in three["experiments"]
    assert "exvivo_point_cloud_with_residual_bc_6dof" in six["experiments"]
