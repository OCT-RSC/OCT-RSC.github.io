import unittest

import numpy as np
import torch

from oct_policy.data import action_transform, split_digest, validate_split_payload
from oct_policy.geometry import relative_tool_pose
from oct_policy.policy import UnifiedPolicyInterface
from oct_policy.training import masked_mse


class DataTests(unittest.TestCase):
    def test_pose_and_action_units(self):
        action = np.array([1, 2, 3, 0, 0, 10], dtype=np.float32)
        transform = action_transform(action)
        np.testing.assert_allclose(transform[:3, 3], action[:3] / 1000)
        np.testing.assert_allclose(relative_tool_pose(np.eye(4), transform), action, atol=1e-6)

    def test_split_rejects_overlap(self):
        split = {"train": ["traj_1"], "validation": ["traj_1"]}
        split["split_sha256"] = split_digest(split)
        with self.assertRaises(ValueError):
            validate_split_payload(split)

    def test_missing_history_repeats_oldest(self):
        self.assertEqual(UnifiedPolicyInterface._repeat_oldest([1, 2], 3), [1, 1, 2])
        self.assertEqual(UnifiedPolicyInterface._repeat_oldest([1, 2, 3, 4], 3), [2, 3, 4])

    def test_future_padding_is_not_scored(self):
        prediction = torch.tensor([[[0.0] * 6, [100.0] * 6]])
        reference = torch.zeros_like(prediction)
        self.assertEqual(masked_mse(prediction, reference, torch.tensor([[1, 0]])).item(), 0)


if __name__ == "__main__":
    unittest.main()
