import unittest
from pathlib import Path

import torch

from oct_policy.config import load_config
from oct_policy.encoders import CosineSchedule
from oct_policy.models import build_policy, predict_actions


CONFIGS = Path(__file__).resolve().parents[1] / "configs"


def sparse_frame(count):
    return {
        "coordinates": torch.tensor([[i, i, i] for i in range(count)], dtype=torch.int32),
        "features": torch.ones(count, 1),
    }


class ModelTests(unittest.TestCase):
    def test_all_phantom_models(self):
        torch.set_num_threads(2)
        for path in sorted(CONFIGS.glob("phantom_*.json")):
            with self.subTest(config=path.name):
                config = load_config(path)
                model = build_policy(config).eval()
                if config["representation"] == "point_cloud":
                    observations = torch.rand(1, 3, 1024, 3)
                    target = torch.rand(1, 1024, 3)
                elif config["representation"] == "tissue_only":
                    observations = [[sparse_frame(n) for n in (8, 13, 5)]]
                    target = [sparse_frame(9)]
                else:
                    # Small spatial input exercises the encoder; production uses 256^3.
                    observations = torch.rand(1, 3, 32, 32, 32)
                    target = torch.rand(1, 32, 32, 32)
                batch = {"observations": observations, "target": target,
                         "tool_poses": torch.zeros(1, 3, 6)}
                schedule = CosineSchedule(100, "cpu") if config["head"] == "diffusion" else None
                prediction = predict_actions(
                    model, schedule, batch, inference_steps=20,
                    generator=torch.Generator().manual_seed(42),
                )
                self.assertEqual(tuple(prediction.shape), (1, 8, 6))
                self.assertTrue(torch.isfinite(prediction).all())
                self.assertLessEqual(prediction.abs().max().item(), 1.0)


if __name__ == "__main__":
    unittest.main()
