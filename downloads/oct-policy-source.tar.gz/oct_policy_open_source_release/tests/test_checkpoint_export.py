from __future__ import annotations

from pathlib import Path

import torch

from oct_policy.checkpoint import export_inference_checkpoint
from oct_policy.experiments import resolve_experiment
from tissue_ai_ui_bundle.policy_experiments.config import load_config, torch_load
from tissue_ai_ui_bundle.policy_experiments.models import build_policy


def test_inference_export_preserves_ema_weights(tmp_path: Path) -> None:
    config = load_config(resolve_experiment("phantom_point_cloud_with_residual_bc"))
    config["config_path"] = (
        r"H:\\private\\configs\\phantom_point_cloud_with_residual_bc.json"
    )
    model = build_policy(config)
    source = tmp_path / "checkpoint_best.pt"
    torch.save(
        {
            "schema": config["schema"],
            "config": config,
            "config_digest": config["config_digest"],
            "split_sha256": "split",
            "cache_sha256": "cache",
            "evaluation_weights": "ema",
            "objective": "deterministic_action_chunk",
            "best_epoch": 7,
            "best_score": 0.1,
            "model_ema": model.state_dict(),
            "model_raw": model.state_dict(),
            "optimizer": {"not": "needed for inference"},
        },
        source,
    )
    output = tmp_path / "inference.pt"

    result = export_inference_checkpoint(source, output)
    exported = torch_load(output, map_location="cpu")

    assert exported["export_format"] == "inference_only_ema_v1"
    assert "model_raw" not in exported
    assert "optimizer" not in exported
    assert exported["config"]["config_path"] == resolve_experiment(
        "phantom_point_cloud_with_residual_bc"
    ).name
    assert result["bytes"] == output.stat().st_size
    for name, expected in model.state_dict().items():
        assert torch.equal(exported["model_ema"][name], expected)
