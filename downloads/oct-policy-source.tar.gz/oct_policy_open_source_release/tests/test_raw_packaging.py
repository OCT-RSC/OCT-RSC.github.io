from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).parents[1]
SPEC = importlib.util.spec_from_file_location(
    "package_mini_raw", ROOT / "tools/package_mini_raw.py"
)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_absolute_paths_are_removed_from_packaged_json() -> None:
    source = {
        "unix": "/private/data/trajectory/target_volume.npy",
        "windows": r"H:\\private\\trajectory\\ascans.npy",
        "unix_target": "/private/traj/predeform/targets/depth/gaussian_displacement_yx_mm.npy",
        "windows_target": (
            r"H:\\private\\traj\\predeform\\targets\\tilt\\"
            r"gaussian_displacement_yx_mm.npy"
        ),
        "relative": "targets/selected/displacement.npy",
        "matrix": [[1.0, 0.0], [0.0, 1.0]],
    }
    sanitized = MODULE.sanitize_json(source)
    assert sanitized["unix"] == "target_volume.npy"
    assert sanitized["windows"] == "ascans.npy"
    assert sanitized["unix_target"] == (
        "targets/depth/gaussian_displacement_yx_mm.npy"
    )
    assert sanitized["windows_target"] == (
        "targets/tilt/gaussian_displacement_yx_mm.npy"
    )
    assert sanitized["relative"] == source["relative"]
    assert sanitized["matrix"] == source["matrix"]
