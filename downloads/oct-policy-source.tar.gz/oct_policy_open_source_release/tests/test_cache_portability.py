from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from tissue_ai_ui_bundle.policy_experiments.config import CACHE_SCHEMA, load_config
from tissue_ai_ui_bundle.policy_experiments.data import (
    PolicyDataset,
    _sha256_file,
    cache_manifest_digest,
    representation_cache_spec,
)
from tissue_ai_ui_bundle.policy_experiments.config import config_digest


ROOT = Path(__file__).parents[1]
CONFIG = (
    ROOT
    / "src"
    / "tissue_ai_ui_bundle"
    / "policy_experiments"
    / "configs"
    / "phantom_point_cloud_with_residual_bc.json"
)


def test_relative_cache_paths_survive_directory_move(tmp_path: Path) -> None:
    config = load_config(CONFIG)
    original = tmp_path / "original"
    trajectory = original / "sample"
    trajectory.mkdir(parents=True)
    paths = []
    for name in ("observation_000.npy", "observation_001.npy", "target.npy"):
        path = trajectory / name
        np.save(path, np.zeros((1024, 3), dtype=np.float32))
        paths.append(path)
    observations = [f"sample/{paths[0].name}", f"sample/{paths[1].name}"]
    manifest = {
        "schema": CACHE_SCHEMA,
        "representation_config_digest": config_digest(
            representation_cache_spec(config)
        ),
        "material": "phantom",
        "representation": "point_cloud",
        "trajectories": [
            {
                "id": "mini/traj_1",
                "observations": observations,
                "observation_sha256": [
                    _sha256_file(paths[0]),
                    _sha256_file(paths[1]),
                ],
                "target": f"sample/{paths[2].name}",
                "target_sha256": _sha256_file(paths[2]),
                "tool_poses": [[0.0] * 6, [0.0] * 6],
                "actions": [[0.0] * 6],
            }
        ],
    }
    manifest["cache_sha256"] = cache_manifest_digest(manifest)
    (original / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    moved = tmp_path / "moved"
    original.rename(moved)

    dataset = PolicyDataset(
        moved / "manifest.json",
        {"mini/traj_1"},
        config,
    )
    sample = dataset[0]
    assert sample["observations"][0].shape == (1024, 3)
    assert sample["target"].shape == (1024, 3)
