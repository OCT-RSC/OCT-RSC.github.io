from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).parents[1]
SOURCE = ROOT / "src" / "tissue_ai_ui_bundle"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_pinned_github_inference_hashes() -> None:
    provenance = json.loads((ROOT / "SOURCE_PROVENANCE.json").read_text())
    for relative, expected in provenance["github_inference_files"].items():
        assert digest(SOURCE / relative) == expected


def test_pinned_training_engine_hash() -> None:
    provenance = json.loads((ROOT / "SOURCE_PROVENANCE.json").read_text())
    assert (
        digest(SOURCE / "policy_experiments" / "engine.py")
        == provenance["verified_training_engine_sha256"]
    )
