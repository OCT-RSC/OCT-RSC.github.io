from __future__ import annotations

from pathlib import Path

import torch

from tissue_ai_ui_bundle.physical_policy.models import CosineSchedule
from tissue_ai_ui_bundle.policy_experiments.config import load_config
from tissue_ai_ui_bundle.policy_experiments.models import build_policy, predict_actions


CONFIGS = (
    Path(__file__).parents[1]
    / "src"
    / "tissue_ai_ui_bundle"
    / "policy_experiments"
    / "configs"
)


def point_cloud_batch(batch_size: int = 2) -> dict:
    return {
        "observations": torch.rand(batch_size, 3, 1024, 3) * 2.0 - 1.0,
        "target": torch.rand(batch_size, 1024, 3) * 2.0 - 1.0,
        "tool_poses": torch.zeros(batch_size, 3, 6),
    }


def sparse_frame(offset: int = 0) -> dict:
    coordinates = torch.tensor(
        [[1 + offset, 2, 3], [2 + offset, 3, 4], [3 + offset, 4, 5]],
        dtype=torch.int32,
    )
    return {"coordinates": coordinates, "features": torch.ones(3, 1)}


def test_point_cloud_bc_shape() -> None:
    config = load_config(CONFIGS / "phantom_point_cloud_with_residual_bc.json")
    policy = build_policy(config).eval()
    prediction = predict_actions(policy, None, point_cloud_batch(), 20)
    assert prediction.shape == (2, 8, 6)
    assert torch.isfinite(prediction).all()


def test_point_cloud_diffusion_shape() -> None:
    config = load_config(CONFIGS / "phantom_point_cloud_with_residual_diffusion.json")
    policy = build_policy(config).eval()
    schedule = CosineSchedule(config["diffusion_steps"], torch.device("cpu"))
    generator = torch.Generator().manual_seed(config["inference_seed"])
    prediction = predict_actions(
        policy,
        schedule,
        point_cloud_batch(batch_size=1),
        inference_steps=2,
        generator=generator,
    )
    assert prediction.shape == (1, 8, 6)
    assert torch.isfinite(prediction).all()


def test_native_sparse_bc_shape() -> None:
    config = load_config(CONFIGS / "phantom_tissue_only_with_residual_bc.json")
    policy = build_policy(config).eval()
    observation_history = [sparse_frame(offset) for offset in range(3)]
    batch = {
        "observations": [observation_history],
        "target": [sparse_frame(1)],
        "tool_poses": torch.zeros(1, 3, 6),
    }
    prediction = predict_actions(policy, None, batch, 20)
    assert prediction.shape == (1, 8, 6)
    assert torch.isfinite(prediction).all()
