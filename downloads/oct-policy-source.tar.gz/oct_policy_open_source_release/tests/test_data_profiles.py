from __future__ import annotations

import json

from oct_policy.experiments import available_data_profiles, resolve_data_profile


def test_data_profiles_separate_dof_regimes() -> None:
    assert set(available_data_profiles()) == {
        "mini_phantom_3dof",
        "official_3dof",
        "official_6dof",
    }
    three = json.loads(resolve_data_profile("official_3dof").read_text())
    six = json.loads(resolve_data_profile("official_6dof").read_text())
    three_prefixes = set(sum(three["include_prefixes"].values(), []))
    six_prefixes = set(sum(six["include_prefixes"].values(), []))
    assert three_prefixes.isdisjoint(six_prefixes)
    assert three["schema"] == six["schema"] == "oct_policy_data_profile_v1"
    assert (three["action_regime"], three["task"]) == ("3dof", "depth")
    assert (six["action_regime"], six["task"]) == ("6dof", "directional")
    assert three["expected_trajectory_counts"] == {"phantom": 40, "exvivo": 30}
    assert six["expected_trajectory_counts"] == {"phantom": 51, "exvivo": 30}
    assert three["expected_action_counts"] == {"phantom": 405, "exvivo": 302}
    assert six["expected_action_counts"] == {"phantom": 535, "exvivo": 321}
    assert three["expected_split_counts"]["phantom"] == {
        "train": 32,
        "validation": 8,
    }
    assert six["expected_split_counts"]["phantom"] == {
        "train": 41,
        "validation": 10,
    }
