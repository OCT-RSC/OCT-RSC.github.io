from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from oct_policy import inference


class _FakePolicy:
    def __init__(self) -> None:
        self.target: Path | None = None
        self.initial_pose: np.ndarray | None = None
        self.scans: list[Path] = []

    def reset(self, target: Path, initial_pose: np.ndarray) -> None:
        self.target = target
        self.initial_pose = initial_pose

    def step(self, scan: Path, pose: np.ndarray) -> dict:
        self.scans.append(scan)
        actions = np.zeros((8, 6), dtype=np.float32)
        return {
            "action_6dof_mm_deg": actions[0],
            "executed_action_sequence_6dof_mm_deg": actions[:1],
            "predicted_action_sequence_6dof_mm_deg": actions,
        }


def test_rollout_paths_are_relative_to_specification(
    tmp_path: Path, monkeypatch
) -> None:
    data = tmp_path / "data"
    data.mkdir()
    target = data / "target.npy"
    scan = data / "scan.npy"
    pose = data / "pose.npy"
    np.save(target, np.zeros((1,), dtype=np.int8))
    np.save(scan, np.zeros((1,), dtype=np.int8))
    np.save(pose, np.eye(4))
    specification = tmp_path / "rollout.json"
    specification.write_text(
        json.dumps(
            {
                "target_volume": "data/target.npy",
                "initial_tooltip_pose": "data/pose.npy",
                "steps": [
                    {"scan": "data/scan.npy", "tooltip_pose": "data/pose.npy"}
                ],
            }
        ),
        encoding="utf-8",
    )
    fake = _FakePolicy()
    monkeypatch.setattr(inference, "load_policy", lambda *_args, **_kwargs: fake)

    output = tmp_path / "predictions.json"
    result = inference.replay_rollout(
        checkpoint=tmp_path / "unused.pt",
        rollout=specification,
        output=output,
    )

    assert fake.target == target.resolve()
    assert fake.scans == [scan.resolve()]
    assert np.array_equal(fake.initial_pose, np.eye(4))
    assert result["steps"] == 1
    assert output.is_file()
