# GitHub runtime integration

## Compatibility boundary

The public training package and the system repository use the same unified
checkpoint schema, `oct_policy_three_input_v1`. Compatibility is determined by
the schema and strict state-dict loading, not by a checkpoint filename.

The following release files are copied from the current GitHub runtime and are
the online inference contract:

- `oct_volume_processing.py`;
- `physical_policy/models.py`, `real_data.py`, and `volume_preprocessing.py`;
- `policy_experiments/interface.py`, `models.py`, and `representations.py`.

The public package adds the verified training-only `data.py` and `engine.py`.
Its `config.py` uses cache schema v2 and validates the fixed experiment matrix;
these additions do not rename model parameters or change checkpoint tensors.

## UI path

The system repository calls
`physical_policy.system_interface.load_policy_interface()`. For a unified
checkpoint, that dispatcher constructs `UnifiedPolicyInterface`, which is the
same class exposed by this repository as `oct_policy.load_policy()`.

Both paths therefore perform the same sequence:

1. read the configuration embedded in the checkpoint;
2. build the representation-specific model;
3. strict-load EMA weights;
4. initialize a trajectory-fixed `RepresentationProcessor` from the target's
   predeformation directory;
5. process three observation states, the saved target volume, relative tooltip
   poses, and the optional residual;
6. predict an `[8,6]` normalized action chunk;
7. multiply by the saved action scale and return the first six-component local
   action for execution.

Robot drivers, scanning, inverse kinematics, stopping, and the V3/V5 GUI are
system integration code and are deliberately not duplicated in this release.

## Directional-target diagnostic

The saved `target_volume.npy` is always the authoritative target input. The
current runtime also contains a diagnostic that warps the predeformation mask
using the saved displacement field. The release follows the current GitHub
column-sign convention for that diagnostic. It does not synthesize or replace
the target tensor used by the policy.
