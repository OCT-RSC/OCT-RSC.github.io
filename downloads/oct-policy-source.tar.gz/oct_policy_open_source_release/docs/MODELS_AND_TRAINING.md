# Models and training

## Shared policy structure

Every model maps the same condition to an eight-action chunk:

```text
observation history (3) ─┐
target representation ──┼─> condition tokens ─> BC or diffusion head ─> [8, 6]
tooltip-pose history ────┘
optional residual ───────┘
```

The embedding width is 128. Observation and pose tokens receive temporal
embeddings. Token-type embeddings distinguish observation, target, tooltip,
and optional residual inputs.

## Representation encoders

### Full volume

The dense encoder is the checkpoint-compatible 3-D CNN used by the completed
runs. Observation history and target are encoded into a `4 x 4 x 4` spatial
token grid. Absolute 3-D spatial position is added before fusion with tooltip
history and optional dense residual tokens.

### Point cloud

A shared PointNet-style encoder applies
`3 -> 64 -> 128 -> 128` pointwise layers, max-pools across points, and uses a
`128 -> 128 -> 128` output MLP. The target and every observation share this
encoder. Residual conditioning is a difference between their encoded features.

### Tissue-only sparse volume

The current implementation is a native PyTorch sparse CNN. It stores only
active coordinates and uses four `3 x 3 x 3` coordinate-neighborhood blocks:

```text
(intensity + normalized DHW) -> 32 -> 64 -> 128 -> 128
```

The last three blocks use stride-two sparse voxel-mean pooling, followed by
global mean pooling over active voxels. Residual input adds signed intensity
and occupancy-difference channels and uses an independent encoder. The native
implementation replaced the original MinkowskiEngine experiment so the model
can run on Windows and standard PyTorch installations.

## Policy heads

### Deterministic BC

Eight learned action queries cross-attend to the condition tokens. An MLP
directly regresses the normalized `[8,6]` action chunk. There is no diffusion
noise or iterative sampler in this branch.

### Clean-action diffusion

The diffusion head embeds a noisy `[8,6]` action sequence and adds a learned
position for each future step. Four transformer blocks use four-head
cross-attention to condition tokens and a `128 -> 512 -> 128` feed-forward
network. A sinusoidal timestep embedding conditions every block. The final
linear layer predicts the clean normalized action `x0`, not epsilon.

Training draws one of 100 cosine-schedule noise levels. Inference performs 20
deterministic denoising updates from one Gaussian sample. The system executes
only the first predicted action, obtains a new OCT scan and tooltip pose, and
then replans.

## Optimization

The completed matrix used the same trainer for both heads and both DoF regimes:

- AdamW, learning rate `1e-4`, weight decay `1e-4`;
- batch size 1 and constant learning rate;
- EMA decay 0.995;
- at most 100 epochs;
- at least 10 epochs, then early stopping after 10 checks without an
  improvement of `1e-4`;
- seed 42 for training, validation, inference noise, representation sampling,
  and split generation;
- masked MSE over valid future steps.

The checkpoint-selection score is normalized first-action MSE, first averaged
over states inside each validation trajectory and then macro-averaged across
trajectories. Reports additionally give translation RMSE in millimetres and
rotation RMSE in degrees for both the first action and the valid horizon.

## Checkpoint contents

`checkpoint_last.pt` supports exact resume and stores:

- raw and EMA model states;
- optimizer, scheduler, and mixed-precision scaler;
- DataLoader generator and Python/NumPy/PyTorch/CUDA RNG states;
- epoch, best score, early-stopping counter, and metric history;
- complete model config;
- frozen split hash and representation-cache hash.

`checkpoint_best.pt` uses the same schema. Evaluation and online rollout load
`model_ema` because the checkpoint declares `evaluation_weights = "ema"`.
`oct-policy reproduce` and `oct-policy matrix` automatically create the smaller
inference-only EMA file beside each completed training run.
`oct-policy export-checkpoint` provides the same conversion when training and
export are run as separate stages. This is the format used by the released
GitHub weights and it does not change any EMA tensor.
