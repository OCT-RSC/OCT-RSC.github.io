# 3-DoF / 6-DoF consistency audit

## Conclusion

The released 3-DoF and 6-DoF rollout policies follow one training and data
processing protocol. They are not all products of a byte-identical historical
source directory: later source added dataset-prefix filtering and replaced the
original optional sparse backend with the native PyTorch sparse CNN. These
changes generalized data selection and produced the current tissue-only
checkpoints; they did not create a different BC or diffusion objective.

## What is identical

- Configuration schema, windows, scaling, seeds, optimizer, EMA, early
  stopping, validation metric, and checkpoint schema.
- Full-volume, tissue-mask, point-cloud, target, residual, and coordinate
  conventions.
- Training/validation engine. The authoritative 3-DoF and 6-DoF `engine.py`
  files have the same SHA-256 digest:
  `a2051349efddd316dce45e9ec21935d7cdf808c72138508143171c11e72016eb`.
- Representation implementation. Both use digest:
  `2bcd41fb0274b3c2567a172c64532ac04d378d91e36b43f2ba0328bf8600eca3`.
- Action tensor shape `[8,6]` and online execution of its first row.

## Intentional differences

| Item | 3-DoF | 6-DoF |
|---|---|---|
| Labels | XYZ translation; rotation components are zero | XYZ translation and XYZ rotation |
| Data groups | 3-DoF depth groups | five phantom tilt groups and three ex-vivo tilt groups |
| Phantom split | 32 / 8 trajectories | 41 / 10 trajectories |
| Ex-vivo split | 24 / 6 trajectories | 24 / 6 trajectories |

The later `data.py` added `include_prefixes` so discovery cannot mix 3-DoF and
6-DoF folders stored under the same root. This changes selection, not
per-trajectory preprocessing.

The first tissue-only runs used MinkowskiEngine. Four 3-DoF tissue-only
policies were subsequently retrained with `native_sparse_cnn_v1`; the official
6-DoF tissue-only policies use the same native backend. The release therefore
uses only the native checkpoints as the current tissue-only results. Historical
MinkowskiEngine checkpoints are not part of the public compatibility set.

## Completed policy set

For each DoF regime, the main matrix contains:

- phantom: 3 representations x 2 residual settings x 2 policy heads = 12;
- ex vivo: full-volume + residual + diffusion = 1.

Two later ex-vivo point-cloud + residual + BC checkpoints, one for 3-DoF and
one for 6-DoF, use the same frozen ex-vivo splits as the corresponding
full-volume diffusion runs. Full-chain verification confirmed exact online vs
cached point-cloud preprocessing, strict checkpoint loading, finite `[8,6]`
inference, and deterministic BC output after reset.

## Source provenance

The training engine and cache builder come from the latest verified training
package. The online interface, representation encoders, and representation
processor follow the current GitHub runtime. Core files remain under their
historical Python namespace to preserve state-dict names and integration
imports. The only representation-source difference from the archived training
package is the corrected column sign in a target-warp diagnostic; model inputs
continue to be extracted directly from `target_volume.npy`, so this diagnostic
change does not alter training or rollout tensors.
