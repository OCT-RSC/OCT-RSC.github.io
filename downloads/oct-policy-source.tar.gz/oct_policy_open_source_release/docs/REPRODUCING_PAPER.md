# Reproducing the policy experiments

## What is reproducible from demonstrations

Given the released raw demonstrations, this repository reproduces:

1. trajectory validation and the target-conditioned sample contract;
2. the seed-42 trajectory split;
3. artifact cleanup and all three input representations;
4. three-state histories, eight-action labels, and valid-tail masks;
5. deterministic BC or clean-action diffusion training;
6. EMA checkpoint selection on frozen-validation first-action normalized MSE;
7. validation metrics and per-state offline action predictions;
8. closed-loop-compatible inference from saved scans.

The robot drivers and graphical user interface are deliberately not part of
the learning-code release. Physical closed-loop results additionally require
the robot, OCT scanner, and deployment dataset.

## Three levels of checking

### 1. Unit and contract tests

```bash
pytest -q
```

These check input/output shapes, cache relocation, experiment discovery,
configuration separation, source provenance, and representative model forward
passes. They do not train a model.

### 2. Two-trajectory pipeline reproduction

Use the installed `mini_phantom_3dof` profile with any one experiment, or run
the complete twelve-model matrix. This verifies every stage with real OCT data
at modest cost. Metrics from two trajectories are pipeline diagnostics, not
paper results.

```bash
oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile mini_phantom_3dof \
  --matrix phantom_paper \
  --output outputs/mini_matrix
```

### 3. Full phantom training matrix

Run the same twelve configurations once with each official data profile:

```bash
oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_3dof \
  --matrix phantom_paper \
  --output outputs/phantom_3dof

oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_6dof \
  --matrix phantom_paper \
  --output outputs/phantom_6dof
```

The two runs produce the 24 phantom checkpoints: twelve model configurations
for depth control and the same twelve for directional control. Configuration,
split, representation-cache, and environment metadata are saved beside every
result.

The four ex vivo checkpoints use two configurations in each action regime:

```bash
oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_3dof \
  --matrix exvivo_3dof \
  --output outputs/exvivo_3dof

oct-policy matrix \
  --data-root /path/to/official_data \
  --data-profile official_6dof \
  --matrix exvivo_6dof \
  --output outputs/exvivo_6dof
```

To compare one newly trained checkpoint with its released counterpart on the
same current validation cache:

```bash
oct-policy compare \
  --prepared outputs/phantom_3dof/prepared/point_cloud \
  --reference checkpoints/phantom_point_residual_bc.pt \
  --candidate outputs/phantom_3dof/experiments/phantom_point_cloud_with_residual_bc/checkpoint_best.pt \
  --output outputs/phantom_3dof/point_residual_bc_comparison.json \
  --device cuda
```

This explicit comparison allows the historical checkpoint's stored cache path
or cache hash to differ, while requiring strict model loading and evaluating
both policies on identical current samples and metric code.

The public official profiles explicitly record dataset-prefix filters so a
shared data root cannot mix 3-DoF and 6-DoF collections. The original phantom
split file stored `include_prefixes = null`; the public file stores the four
selected depth prefixes. This metadata changes the split SHA-256, but the 32
training and eight validation trajectory IDs are identical to the original
paper run.

The full-data verification additionally compared all 485 generated
Point-cloud representation arrays with the archived paper-training cache. The
relative file sets and every file byte were identical. The retrained
Point-cloud + residual BC policy reached 0.45356 mm first-action translation
RMSE; the current released checkpoint reached 0.45397 mm on the same cache and
validation IDs. See `FULL_DATA_REPRODUCTION.json` for the machine-readable
record.

## Interpreting the outputs

`checkpoint_best.pt` is selected only from the frozen validation trajectories.
Its primary score is first-action normalized MSE, averaged within trajectory
and then across trajectories. Translation and rotation RMSE are reported in
millimetres and degrees for interpretation.

These validation metrics measure agreement with demonstrated actions. The
paper's shape RMSE and HD95 measure physical rollout geometry and are computed
from newly executed robot trajectories; they cannot be recreated by training
logs alone.
