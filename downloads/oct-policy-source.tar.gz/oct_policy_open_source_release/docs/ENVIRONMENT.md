# Verified software environment

The release is standard Python and PyTorch code; it does not require
MinkowskiEngine. The end-to-end real-data verification used:

| Component | Verified version |
|---|---|
| Python | 3.12.11 |
| NumPy | 1.26.4 |
| SciPy | 1.16.2 |
| PyTorch | 2.10.0+cu128 |
| CUDA runtime used by PyTorch | 12.8 |
| Great Lakes CUDA module | 12.8.2 |
| cuDNN | 9.10.2 |
| GPU | NVIDIA A40 |

The minimum versions in `pyproject.toml` are broader so inference can run in
ordinary PyTorch environments. For the closest training reproduction, use the
versions above. Each `oct-policy reproduce` or `oct-policy matrix` run writes
an `environment.json` file containing the actual Python, package, CUDA, cuDNN,
and GPU versions used for that run.

Small floating-point differences across GPU models or PyTorch releases are
expected. Reproduction should compare the frozen split and cache hashes,
checkpoint schema, validation metric definitions, and numerical trends rather
than requiring byte-identical learned weights across hardware.
