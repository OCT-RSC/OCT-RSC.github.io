# Data and preprocessing

## Saved trajectory contract

Each demonstration is one directory:

```text
trajectory/
  predeform/
    ascans.npy
    target_volume.npy
    target_selection.json
    targets/.../gaussian_displacement_yx_mm.npy
  0/
    ascans.npy
    step_info.json
  1/
    ascans.npy
    step_info.json
  ...
```

OCT arrays are signed 8-bit volumes stored as either
`[1, 256, 256, 768, 1]` or the equivalent `[256, 256, 768]` HWD array. The
predeform scan is state 0. Numeric step `t` stores the scan after action `t`
and the resulting tooltip transform. The loader reconstructs the initial pose
from the first saved post-action pose and first local action.

The action convention is

```text
pose[t + 1] = pose[t] @ local_delta(x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg)
```

where rotations use Euler XYZ angles. All policies output six components. A
3-DoF dataset simply has zero rotation labels; its tensor and checkpoint shapes
are intentionally identical to 6-DoF models.

## Target source

`target_volume.npy` is the authoritative model target. The Gaussian
displacement sidecar is used to construct or diagnose the target, but the
released model pipeline does not substitute the predeform volume or a warped
surface for the saved target volume.

## Common OCT cleanup and coordinates

Every representation uses the same trajectory-fixed OCT cleanup. Measured air
from the predeform scan replaces scanner/tool artifacts. Individual frames are
never independently recentered. Saved HWD data are converted to policy DHW and
the established scanner-X flip is retained.

The three representation contracts are:

| Representation | Model input | Construction |
|---|---|---|
| Full volume | float volume `[256,256,256]` | Clean, normalize with fixed OCT mean/std, clip to `[-5,5]`, HWD→DHW, X flip, trilinear resize |
| Tissue only | variable active voxels `(D,H,W,intensity)` on `[72,128,128]` | Extract a solid visible-tissue mask from the cleaned volume, resample mask and intensity, retain every active coordinate |
| Point cloud | float array `[1024,3]` | Sample tissue-mask points in scanner-fixed physical XYZ and normalize the fixed FOV to `[-1,1]` |

Point clouds contain no intensity. If a mask has fewer than 1024 voxels, real
points are sampled with replacement; zero-padding is not used. Sparse tissue
inputs keep normalized absolute DHW coordinates as encoder channels.

For residual models:

- full volume uses `processed_target - processed_observation`;
- point cloud uses the feature difference
  `encoder(target) - encoder(observation)`, not row-wise point subtraction;
- tissue-only builds a coordinate union with signed intensity and occupancy
  differences and processes it with a separate sparse encoder.

## Windows and action targets

A demonstration with `L` actions contributes `L` samples, for states
`0 ... L-1`.

- The observation window is 3. At the start of a rollout, the oldest available
  real state is repeated on the left.
- The prediction window is 8. The label at state `t` is the next eight recorded
  local deltas.
- Near the trajectory end, missing future slots are stored as zero only to keep
  a rectangular tensor. Their mask is zero and they do not contribute to the
  loss.
- No repeated terminal observation or synthetic zero-action demonstration was
  inserted into these training runs. System stopping is handled separately.

Actions are divided by `[2,2,2,2,2,2]`; relative tooltip pose components are
divided by `[20,20,20,20,20,20]` before entering the model.

## Frozen split

The split is trajectory-level and group-stratified, using seed 42 and 20%
validation within each collection group. Every representation, residual
setting, and policy head for one data regime uses the same split file.
The installed official data profiles also record the expected trajectory,
action, and split counts, so preprocessing fails clearly if a release dataset
is incomplete.

Completed runs used:

| Regime | Material | Trajectories | Actions | Train / validation trajectories |
|---|---|---:|---:|---:|
| 3-DoF | Phantom | 40 | 405 | 32 / 8 |
| 3-DoF | Ex vivo | 30 | 302 | 24 / 6 |
| 6-DoF | Phantom | 51 | 535 | 41 / 10 |
| 6-DoF | Ex vivo | 30 | 321 | 24 / 6 |

Together these profiles contain 151 trajectories, 1,563 actions, and 1,714
OCT states when each trajectory's initial scan is included.

Representation caches contain source-relative trajectory IDs, processed files,
configuration hashes, content hashes, normalized tooltip histories, and raw
physical action labels. Training verifies split and cache hashes before use.
Cached representation paths are stored relative to `manifest.json`; older
absolute-path manifests remain readable. A prepared mini cache can therefore
be archived, moved, and smoke-tested on another machine without rewriting its
file paths.
