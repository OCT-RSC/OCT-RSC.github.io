# Release verification

The cleanup was checked against the completed training artifacts on
2026-10-01.

## Source provenance

Seven inference-critical files are byte-identical to GitHub commit
`b7dcc67494589264cf6f17a3ff7e803a13b97873`: OCT volume processing, the three
shared physical-policy files, and the unified interface, model, and
representation modules. Their hashes are pinned and tested in
`SOURCE_PROVENANCE.json`.

The training engine is byte-identical to the completed verified training
package. The cache builder retains that preprocessing and sample construction,
with one release-only change: generated cache paths are relative to
`manifest.json` so a prepared mini dataset can be moved. The release config
keeps cache schema v2 and fixed-experiment validation while excluding the
superseded MinkowskiEngine backend.

## Checkpoint loading

All 39 `.pt` files in the current GitHub checkpoint directory were inspected.
Twenty-eight declare the unified schema and all 28 load with `strict=True` and
no missing or unexpected keys. They comprise 14 policies per DoF regime: the
12 phantom representation/residual/head configurations plus ex-vivo
full-volume residual Diffusion and ex-vivo point-cloud residual BC.

The remaining 11 files have no unified schema and are historical legacy
checkpoints. They are classified rather than silently treated as current
experiment weights. The complete name, SHA-256, schema, embedded configuration,
and load result are recorded in `CHECKPOINT_COMPATIBILITY.json`.

All 28 loaded with no missing or unexpected state-dict keys. The set covers:

| Axis | Counts |
|---|---|
| Representation | 10 full volume, 10 point cloud, 8 tissue only |
| Head | 14 diffusion, 14 deterministic BC |
| Residual | 16 with residual, 12 without residual |

The compact-export path was checked against the released phantom
Point-cloud+residual BC weight. The full training checkpoint has SHA-256
`9be3c743126e774f1c24a4ebaa2842635b39e704def512d2fcc77915f9b43fd2`.
Both `oct-policy export-checkpoint` and the GitHub file record that source hash,
contain the same inference-only key set, and have identical EMA tensor content
(aggregate tensor SHA-256
`9934cc75b13af79da6b2cc28b02e96a6c81578602f27761f1d59060db21ce706`).

The current GitHub `load_policy_interface()` dispatcher was also exercised
directly with one Full-volume, one Point-cloud, and one Tissue-only checkpoint.
All three selected `UnifiedPolicyInterface` and reported the expected embedded
representation, head, and residual setting.

## Executable tests

The repository test suite passed 15 tests; one optional checkpoint test was
skipped because it is gated by `OCT_POLICY_CHECKPOINT`. An isolated wheel was
built and installed successfully, including all experiment, matrix, and data
profile resources.

The tests execute point-cloud BC, point-cloud diffusion, and native sparse BC
forward paths and require finite `[batch, 8, 6]` outputs. They also cover
portable caches, raw-package path sanitization, installed configuration
discovery, compact checkpoint export, and relative saved-rollout paths. A
separate real-cache smoke test loaded one held-out official ex-vivo trajectory
in each DoF regime:

| Checkpoint | Cached input | Output | Result |
|---|---|---|---|
| 3-DoF ex-vivo point-cloud residual BC | validation trajectory | `[1,8,6]` | finite and deterministic |
| 6-DoF ex-vivo point-cloud residual BC | validation trajectory | `[1,8,6]` | finite and deterministic |

The completed training handoffs additionally record online-vs-cache equality,
GPU sequential inference, and deterministic reset checks for these two
checkpoints. Private paths and data are deliberately not copied into this
repository.

## Real-data mini reproduction

The installed official profiles were first checked against the source tree:
40 phantom 3-DoF trajectories with 405 actions, 51 phantom 6-DoF trajectories
with 535 actions, and 30 ex-vivo trajectories in each regime with 302 and 321
actions. These totals sum to the paper inventory of 151 trajectories, 1,563
actions, and 1,714 OCT states including each initial scan. The workflow now
enforces these counts before preprocessing an official profile.

The public commands were also run end to end on two real phantom 3-DoF
demonstrations selected by the `mini_phantom_3dof` profile. The frozen split
contained one training trajectory (11 action samples) and one validation
trajectory (10 action samples). The job completed in 4 min 38 s, including raw-OCT
preprocessing, cache hashing, strict loading of the official point-cloud
residual BC checkpoint, 100 training epochs, final validation, and reloading
the newly trained checkpoint.

Both official and newly trained checkpoints produced finite `[1,8,6]` action
chunks. The mini run's final first-action translation RMSE was 0.535 mm; this is
a pipeline reproduction check, not a reported experimental result. The
path-sanitized prepared cache is 424 KB (104 KB compressed), contains no local
or cluster paths, and passed full checksum verification and inference after
relocation. The same real sample was also evaluated with the checkpoint file
currently in GitHub and produced the same action as the verified training-run
checkpoint to numerical precision.

The complete twelve-configuration phantom matrix was then run on the same two
real trajectories. All twelve runs completed with finite validation metrics
and an empty scheduler error log. They shared one frozen split
(`aa9e0c1e32219c2870055157503108f5c5c733fd7b6106ef937a665418b3e1bc`)
and exactly one content-addressed cache per representation. This exercised
Full-volume, Tissue-only, and Point-cloud inputs with both action heads and
both residual settings. The run used Python 3.12.11, PyTorch 2.10.0, CUDA 12.8,
cuDNN 9.10.2, and an NVIDIA A40. These two-trajectory scores are deliberately
not presented as paper results; their purpose is to prove that every public
configuration executes the same raw-data-to-action workflow.

## Full-data training reproduction

One representative paper configuration, phantom Point-cloud + residual BC,
was then reproduced from all 40 official 3-DoF demonstrations. The public
workflow discovered 405 actions and 445 OCT states, recovered the original
32/8 trajectory split, trained for 67 epochs with early stopping, selected
epoch 57, exported a compact checkpoint, and emitted predictions for all 82
validation states. The run completed without scheduler errors on an NVIDIA A40.

The strongest preprocessing check compared every cached representation array
with the archived paper-training cache. Both caches contained the same 485
relative `.npy` paths, and all 485 files were byte-identical. Their manifest
hashes differ because the public manifest is relocatable and its split records
the four selected dataset prefixes explicitly; the train and validation IDs
are unchanged.

The retrained policy obtained a first-action translation RMSE of 0.45356 mm on
the frozen validation split. The current released checkpoint obtained
0.45397 mm when evaluated by the same code on the same newly generated cache,
a difference of 0.00041 mm. These are offline action-prediction metrics, not
physical shape metrics.

The automatically exported `checkpoint_inference.pt` contains the exact 27
EMA tensors selected at epoch 57 and no optimizer, scheduler, history, scaler,
or RNG state. Its aggregate EMA tensor SHA-256 is
`30d4f60db2a348f75b2efb986f53d02b2c707d94ad6fd39a68817a055fdb296d`.
Strict inference produced finite `[8,6]` action chunks for all 82 validation
states. Machine-readable evidence is stored in
`FULL_DATA_REPRODUCTION.json`.

To check another private checkpoint after installation:

```bash
OCT_POLICY_CHECKPOINT=/path/to/checkpoint_best.pt pytest -q
```
