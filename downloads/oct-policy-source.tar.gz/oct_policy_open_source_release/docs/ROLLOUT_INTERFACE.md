# Closed-loop rollout interface

The system owns scanning, robot motion, and stopping. The policy owns action
chunk prediction.

```python
policy.reset(target_volume_path, initial_tooltip_pose_4x4)

while not stopped:
    scan_path, current_pose = scan_and_read_pose()
    result = policy.step(scan_path, current_pose)
    execute_local_delta(result["action_6dof_mm_deg"])
```

`reset()` fixes the target and initial tooltip frame, clears the three-state
history, and resets diffusion sampling to the checkpoint seed. On the first
two calls to `step()`, the oldest real observation and pose are repeated to
fill the history. There are no fabricated all-zero OCT frames.

Each `step()`:

1. preprocesses the new scan with the same trajectory-fixed processor used for
   caching;
2. converts the current tooltip pose to the initial-tooltip local frame;
3. encodes the three-state history, target, pose history, and optional residual;
4. predicts an `[8,6]` local action chunk;
5. returns the first `[6]` action for execution.

The six action values are
`[x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg]`. The caller should acquire a new
scan after executing the first action and call `step()` again. It should not
open-loop execute the remaining seven predictions under the released
configuration (`execute_window = 1`).

The `4 x 4` tooltip transforms follow the saved robot convention: translation
entries are in metres and the upper-left block is a rotation matrix. The
policy converts the relative translation to millimetres and the relative
rotation to a rotation vector in degrees before applying the saved pose scale.

Stopping is external to these checkpoints. The training set did not add
repeated terminal states with zero-action labels. A system may stop when the
tooltip remains within an application-defined motion tolerance for several
closed-loop cycles, but that decision is not produced by this model.

For offline replay, `oct-policy infer` reads the equivalent sequence from one
JSON file. Relative target, scan, and pose paths are resolved from the JSON
file's directory, so a saved rollout can be moved as one folder.
