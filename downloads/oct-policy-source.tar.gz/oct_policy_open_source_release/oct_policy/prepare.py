"""Prepare raw demonstrations for training."""

import json
from pathlib import Path

from .config import write_json_atomic
from .data import (
    audit_dataset,
    build_cache,
    create_frozen_split,
    validate_cache_manifest,
    validate_split_payload,
)


def open_prepared(directory: str | Path) -> tuple[Path, Path]:
    root = Path(directory).resolve()
    metadata = json.loads((root / "prepared.json").read_text())
    if metadata.get("schema") != "oct_policy_prepared_data_v1":
        raise ValueError("Not a prepared OCT dataset")
    manifest_path = root / metadata["manifest"]
    split_path = root / metadata["split"]
    manifest = json.loads(manifest_path.read_text())
    split = json.loads(split_path.read_text())
    validate_cache_manifest(manifest)
    validate_split_payload(split)
    if manifest["split_sha256"] != split["split_sha256"]:
        raise ValueError("Cache and training/validation split do not match")
    for key in ("cache_sha256", "split_sha256"):
        if metadata.get(key) not in (None, manifest[key]):
            raise ValueError(f"prepared.json has an inconsistent {key}")
    return manifest_path, split_path


def prepare_dataset(
    data_root: Path,
    config: dict,
    output: Path,
    data_profile: Path | None = None,
    overwrite: bool = False,
) -> Path:
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    profile = json.loads(data_profile.read_text()) if data_profile else {}
    prefixes = profile.get("include_prefixes", {}).get(config["material"])
    if data_profile and prefixes is None:
        raise ValueError(f"Data profile has no {config['material']} trajectories")
    audit = audit_dataset(data_root, output / "audit.json", include_prefixes=prefixes)
    if audit["error_count"]:
        raise ValueError(f"Invalid trajectories; see {output / 'audit.json'}")
    count = audit["material_counts"].get(config["material"], 0)
    actions = sum(
        item["steps"] for item in audit["trajectories"]
        if item["material"] == config["material"]
    )
    for key, observed in (("expected_trajectory_counts", count), ("expected_action_counts", actions)):
        expected = profile.get(key, {}).get(config["material"])
        if expected is not None and observed != expected:
            raise ValueError(f"{key}: expected {expected}, found {observed}")
    split_path = output / "split.json"
    split = create_frozen_split(
        data_root, config["material"], split_path,
        seed=config["split_seed"], include_prefixes=prefixes,
    )
    if not split["train"] or not split["validation"]:
        raise ValueError("Need at least two demonstrations per target condition")
    counts = {"train": len(split["train"]), "validation": len(split["validation"])}
    expected = profile.get("expected_split_counts", {}).get(config["material"])
    if expected is not None and counts != expected:
        raise ValueError(f"Expected split {expected}, found {counts}")
    manifest = build_cache(data_root, split_path, config, output / "cache", overwrite)
    cached = json.loads(manifest.read_text())
    write_json_atomic(output / "prepared.json", {
        "schema": "oct_policy_prepared_data_v1",
        "manifest": manifest.relative_to(output).as_posix(),
        "split": "split.json",
        "material": config["material"],
        "representation": config["representation"],
        "cache_sha256": cached["cache_sha256"],
        "split_sha256": split["split_sha256"],
        "train_trajectories": counts["train"],
        "validation_trajectories": counts["validation"],
        "actions": actions,
    })
    return output
