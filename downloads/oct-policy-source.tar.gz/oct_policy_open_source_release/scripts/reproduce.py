#!/usr/bin/env python3
"""Compatibility entry point for ``oct-policy reproduce``."""

import sys

from oct_policy.cli import main


if __name__ == "__main__":
    main(["reproduce", *sys.argv[1:]])
