# Release notice

This cleanup contains code only. It intentionally omits private OCT data,
checkpoints, generated caches, robot/vendor SDKs, local filesystem paths, and
Slurm account settings.

Before publishing, the project owner should add the selected open-source
license, authorship/citation information, and any separate terms governing
release of data or trained weights.

