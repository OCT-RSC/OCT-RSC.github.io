"""Standard full-volume diffusion policy: data, training, validation, inference."""

import json
from pathlib import Path


STANDARD_CONFIG_PATH = Path(__file__).parent / "configs" / "standard_256.json"


def load_standard_config(resolution: int = 256) -> dict:
    resolution = int(resolution)
    if resolution < 16:
        raise ValueError("Policy resolution must be at least 16")
    config = json.loads(STANDARD_CONFIG_PATH.read_text())
    config["resolution"] = resolution
    return config
