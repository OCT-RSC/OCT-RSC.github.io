from __future__ import annotations

"""Standard full-volume training data and runtime preprocessing."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.spatial.transform import Rotation
from torch.utils.data import Dataset

from .volume_preprocessing import (
    RAW_FULL,
    FloorAwareVolumePreprocessor,
    open_raw_hwd,
)


DATA_SCHEMA = "full_volume_diffusion_v1"
OCT_MEAN = 10.377689
OCT_STD = 6.639139
DEFAULT_ACTION_SCALE = np.asarray([2, 2, 2, 2, 2, 2], dtype=np.float32)
DEFAULT_TOOL_SCALE = np.asarray([20, 20, 20, 20, 20, 20], dtype=np.float32)


def numeric_steps(trajectory: Path) -> list[Path]:
    return sorted(
        [path for path in Path(trajectory).iterdir() if path.is_dir() and path.name.isdigit()],
        key=lambda path: int(path.name),
    )


def load_raw_volume(path: Path) -> np.ndarray:
    """Load saved OCT and return contiguous [D,H,W] with the standard x flip."""
    raw = open_raw_hwd(path)
    return np.ascontiguousarray(raw.transpose(2, 0, 1)[:, :, ::-1])


def preprocess_volume(
    path: Path,
    resolution: int,
    device: torch.device | str,
    preprocessor: FloorAwareVolumePreprocessor | None = None,
    is_target: bool = False,
) -> np.ndarray:
    """Apply identical orientation, resize, and intensity normalization to any OCT volume."""
    if preprocessor is not None:
        return preprocessor.preprocess(path, resolution, device, is_target=is_target)
    volume = torch.from_numpy(load_raw_volume(path)).to(device=device, dtype=torch.float32)
    volume = F.interpolate(
        volume[None, None],
        size=(resolution, resolution, resolution),
        mode="trilinear",
        align_corners=True,
    )[0, 0]
    volume = ((volume - OCT_MEAN) / OCT_STD).clamp(-5, 5)
    return volume.to(torch.float16).cpu().numpy()


def action_array(record: dict) -> np.ndarray:
    values = record["inputs_6dof_mm_deg"]
    return np.asarray(
        [
            values["dx_mm"],
            values["dy_mm"],
            values["dz_mm"],
            values["d_roll_deg"],
            values["d_pitch_deg"],
            values["d_yaw_deg"],
        ],
        dtype=np.float32,
    )


def action_transform(record: dict) -> np.ndarray:
    action = action_array(record)
    transform = np.eye(4)
    transform[:3, :3] = Rotation.from_euler("xyz", action[3:], degrees=True).as_matrix()
    transform[:3, 3] = action[:3] / 1000.0
    return transform


def relative_tool_pose(initial_pose: np.ndarray, current_pose: np.ndarray) -> np.ndarray:
    """Represent a tooltip pose as local xyz millimetres and rotation-vector degrees."""
    relative = np.linalg.inv(initial_pose) @ current_pose
    translation_mm = relative[:3, 3] * 1000.0
    rotation_deg = np.rad2deg(Rotation.from_matrix(relative[:3, :3]).as_rotvec())
    return np.concatenate((translation_mm, rotation_deg)).astype(np.float32)


def _scale(config: dict, name: str, default: np.ndarray) -> np.ndarray:
    scale = np.asarray(config.get(name, default), dtype=np.float32)
    if scale.shape != (6,) or np.any(scale <= 0):
        raise ValueError(f"{name} must contain six positive values")
    return scale


def find_target_volume(trajectory: Path) -> Path:
    candidates = (
        trajectory / "predeform" / "target_volume.npy",
        trajectory / "target_volume.npy",
    )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        f"No full target volume found for {trajectory}. Expected "
        f"{candidates[0]} or {candidates[1]}."
    )


def _cache_matches(path: Path, resolution: int) -> bool:
    if not path.exists():
        return False
    try:
        return np.load(path, mmap_mode="r").shape == (resolution,) * 3
    except Exception:
        return False


def discover_trajectories(data_root: Path) -> list[tuple[int | str, int, int, Path]]:
    """Find either flat traj_* data or grouped set_<percentage>_per/traj_* data."""
    data_root = Path(data_root)
    discovered: list[tuple[int | str, int, int, Path]] = []

    flat = list(data_root.glob("traj_*"))
    for path in flat:
        try:
            trajectory_index = int(path.name.split("_")[-1])
        except ValueError:
            continue
        discovered.append((trajectory_index, -1, trajectory_index, path))
    if discovered:
        return sorted(discovered, key=lambda item: item[2])

    for target_set in data_root.glob("set_*_per"):
        try:
            percentage = int(target_set.name.split("_")[1])
        except (IndexError, ValueError):
            continue
        for path in target_set.glob("traj_*"):
            try:
                trajectory_index = int(path.name.split("_")[-1])
            except ValueError:
                continue
            trajectory_id = f"{percentage}/traj_{trajectory_index}"
            discovered.append(
                (trajectory_id, percentage, trajectory_index, path)
            )
    return sorted(discovered, key=lambda item: (item[1], item[2]))


def prepare_dataset(
    data_root: Path,
    output: Path,
    config: dict,
    trajectory_ids: set[int | str] | None = None,
    overwrite: bool = False,
) -> Path:
    """Cache normalized observation and target volumes and write one manifest."""
    data_root = Path(data_root)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    resolution = int(config["resolution"])
    action_scale = _scale(config, "action_scale", DEFAULT_ACTION_SCALE)
    tool_scale = _scale(config, "tool_scale", DEFAULT_TOOL_SCALE)
    volume_input_mode = str(config.get("volume_input_mode", RAW_FULL))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    manifest = {
        "schema": DATA_SCHEMA,
        "resolution": resolution,
        "action_scale": action_scale.tolist(),
        "tool_scale": tool_scale.tolist(),
        "volume_input_mode": volume_input_mode,
        "volume_preprocessing": (
            "floor-aware HWD mask + DHW x-flip + trilinear intensity resize + "
            "nearest mask resize + OCT normalization"
        ),
        "trajectories": [],
    }
    trajectories = [
        item
        for item in discover_trajectories(data_root)
        if trajectory_ids is None or item[0] in trajectory_ids
    ]

    for trajectory_id, target_percentage, trajectory_index, trajectory in trajectories:
        destination_name = (
            f"traj_{trajectory_index}"
            if target_percentage < 0
            else f"set_{target_percentage}_per_traj_{trajectory_index}"
        )
        destination = output / destination_name
        destination.mkdir(exist_ok=True)
        steps = numeric_steps(trajectory)
        if not steps:
            raise RuntimeError(f"No numeric steps found in {trajectory}")

        records = [json.loads((step / "step_info.json").read_text()) for step in steps]
        actions = np.stack([action_array(record) for record in records])
        poses_after_action = [
            np.asarray(record["tooltip_transform_4x4"], dtype=np.float64)
            for record in records
        ]
        initial_pose = poses_after_action[0] @ np.linalg.inv(action_transform(records[0]))
        poses = [initial_pose, *poses_after_action]
        tool_poses = [
            (relative_tool_pose(initial_pose, pose) / tool_scale).tolist()
            for pose in poses
        ]

        source_observations = [trajectory / "predeform" / "ascans.npy"] + [
            step / "ascans.npy" for step in steps
        ]
        preprocessor = (
            None
            if volume_input_mode == RAW_FULL
            else FloorAwareVolumePreprocessor(trajectory, volume_input_mode)
        )
        cached_observations = []
        for state, source in enumerate(source_observations):
            cached = destination / f"observation_{state:03d}.npy"
            if overwrite or not _cache_matches(cached, resolution):
                np.save(
                    cached,
                    preprocess_volume(
                        source,
                        resolution,
                        device,
                        preprocessor=preprocessor,
                    ),
                )
            cached_observations.append(str(cached))

        target_source = find_target_volume(trajectory)
        cached_target = destination / "target.npy"
        if overwrite or not _cache_matches(cached_target, resolution):
            np.save(
                cached_target,
                preprocess_volume(
                    target_source,
                    resolution,
                    device,
                    preprocessor=preprocessor,
                    is_target=True,
                ),
            )

        manifest["trajectories"].append(
            {
                "id": trajectory_id,
                "target_percentage": (
                    None if target_percentage < 0 else target_percentage
                ),
                "trajectory_index": trajectory_index,
                "source": str(trajectory),
                "observations": cached_observations,
                "target": str(cached_target),
                "target_source": str(target_source),
                "tool_poses": tool_poses,
                "actions": actions.tolist(),
            }
        )
        print(f"prepared traj_{trajectory_id}: {len(actions)} actions")

    if not manifest["trajectories"]:
        raise RuntimeError(f"No trajectories selected from {data_root}")
    manifest_path = output / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    return manifest_path


class StandardTrajectoryDataset(Dataset):
    def __init__(
        self,
        manifest_path: Path,
        trajectory_ids: set[int | str],
        history: int,
        horizon: int,
        terminal_repeats: int = 3,
    ):
        manifest = json.loads(Path(manifest_path).read_text())
        if manifest.get("schema") != DATA_SCHEMA:
            raise ValueError(f"Expected data schema {DATA_SCHEMA}")
        self.history = int(history)
        self.horizon = int(horizon)
        self.terminal_repeats = int(terminal_repeats)
        self.action_scale = torch.tensor(manifest["action_scale"], dtype=torch.float32)
        self.trajectories = {
            item["id"]: item
            for item in manifest["trajectories"]
            if item["id"] in trajectory_ids
        }
        if not self.trajectories:
            raise RuntimeError(f"No requested trajectories found: {sorted(trajectory_ids)}")
        self.samples = [
            (trajectory_id, state)
            for trajectory_id, trajectory in self.trajectories.items()
            for state in range(len(trajectory["actions"]) + self.terminal_repeats)
        ]

    def __len__(self) -> int:
        return len(self.samples)

    def sample_info(self, index: int) -> tuple[int | str, int]:
        return self.samples[index]

    def __getitem__(self, index: int):
        """Return one state and its next horizon actions.

        A trajectory with L actions contains L+1 states: predeform is state 0,
        and each numbered scan is the state after its recorded action.  State s
        therefore observes volume/pose s and is labelled with actions s:s+K.
        At s >= L, the final state is repeated and all K supervised actions are
        zero, which teaches the policy to stop.
        """
        trajectory_id, state = self.samples[index]
        trajectory = self.trajectories[trajectory_id]
        final_state = len(trajectory["actions"])
        history_indices = [
            min(final_state, max(0, state - self.history + 1 + offset))
            for offset in range(self.history)
        ]
        observations = torch.stack(
            [
                torch.from_numpy(np.load(trajectory["observations"][item])).float()
                for item in history_indices
            ]
        )
        target = torch.from_numpy(np.load(trajectory["target"])).float()
        tool_poses = torch.tensor(
            [trajectory["tool_poses"][item] for item in history_indices],
            dtype=torch.float32,
        )
        action = torch.zeros(self.horizon, 6)
        mask = torch.zeros(self.horizon)
        future = trajectory["actions"][state : state + self.horizon]
        if state >= final_state:
            mask[:] = 1
        elif future:
            action[: len(future)] = torch.tensor(future) / self.action_scale
            mask[: len(future)] = 1
        return observations, target, tool_poses, action, mask


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    print(prepare_dataset(args.data, args.output, config, overwrite=args.overwrite))


if __name__ == "__main__":
    main()
