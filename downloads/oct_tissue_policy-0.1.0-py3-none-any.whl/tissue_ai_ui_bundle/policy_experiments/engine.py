from __future__ import annotations

"""Training, validation, checkpoint/resume, and offline inference."""

import json
import os
import random
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from tissue_ai_ui_bundle.physical_policy.models import CosineSchedule, DIFFUSION_STEPS

from .config import EXPERIMENT_SCHEMA, torch_load, write_json_atomic
from .data import (
    PolicyDataset,
    collate_policy_samples,
    validate_cache_manifest,
    validate_split_payload,
)
from .models import build_policy, predict_actions


def set_global_seed(seed: int) -> None:
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))


def initialize_ema_policy(policy, config: dict, device: torch.device):
    """Create an independent EMA model without deep-copying backend objects."""
    ema_policy = build_policy(config).to(device).eval()
    ema_policy.load_state_dict(policy.state_dict())
    for parameter in ema_policy.parameters():
        parameter.requires_grad_(False)
    return ema_policy


def move_batch(batch: dict, device: torch.device) -> dict:
    moved = dict(batch)
    for name in ("target", "observations", "tool_poses", "actions", "mask", "state"):
        value = moved[name]
        if torch.is_tensor(value):
            moved[name] = value.to(device)
    return moved


def masked_mse(prediction: torch.Tensor, action: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    error = F.mse_loss(prediction, action, reduction="none").mean(dim=-1)
    return (error * mask).sum() / mask.sum().clamp_min(1.0)


def _atomic_torch_save(path: Path, payload: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def _rng_state() -> dict:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }


def _restore_rng_state(state: dict) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if state.get("cuda") is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state["cuda"])


@torch.inference_mode()
def evaluate_model(
    policy,
    config: dict,
    loader: DataLoader,
    device: torch.device,
) -> dict:
    """Evaluate with fixed diffusion noise and trajectory-macro model selection."""
    policy.eval()
    schedule = (
        CosineSchedule(int(config.get("diffusion_steps", DIFFUSION_STEPS)), device)
        if config["head"] == "diffusion"
        else None
    )
    generator = torch.Generator(device=device).manual_seed(int(config.get("validation_seed", 42)))
    action_scale = torch.tensor(config["action_scale"], device=device)
    by_trajectory: dict[str, list[float]] = defaultdict(list)
    first_translation = []
    first_rotation = []
    masked_error_sum = 0.0
    masked_valid_steps = 0.0
    latencies = []
    latency_samples = 0
    horizon_translation_error_sum = 0.0
    horizon_rotation_error_sum = 0.0
    horizon_component_count = 0.0

    for raw_batch in loader:
        batch = move_batch(raw_batch, device)
        if device.type == "cuda":
            torch.cuda.synchronize()
        started = time.perf_counter()
        with torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=device.type == "cuda",
        ):
            prediction = predict_actions(
                policy,
                schedule,
                batch,
                int(config.get("inference_steps", 20)),
                generator,
            )
            loss = masked_mse(prediction, batch["actions"], batch["mask"])
        if device.type == "cuda":
            torch.cuda.synchronize()
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        batch_size = int(batch["actions"].shape[0])
        latencies.append(elapsed_ms)
        latency_samples += batch_size
        valid_steps = float(batch["mask"].sum().item())
        masked_error_sum += float(loss.item()) * valid_steps
        masked_valid_steps += valid_steps

        normalized_squared = (prediction[:, 0] - batch["actions"][:, 0]).square().mean(dim=-1)
        for identifier, value in zip(raw_batch["trajectory_id"], normalized_squared.cpu().tolist()):
            by_trajectory[identifier].append(float(value))
        physical_error = (prediction - batch["actions"]) * action_scale
        first_translation.extend(physical_error[:, 0, :3].square().mean(dim=-1).cpu().tolist())
        first_rotation.extend(physical_error[:, 0, 3:].square().mean(dim=-1).cpu().tolist())
        valid = batch["mask"][:, :, None]
        horizon_translation_error_sum += float(
            (physical_error[..., :3].square() * valid).sum().item()
        )
        horizon_rotation_error_sum += float(
            (physical_error[..., 3:].square() * valid).sum().item()
        )
        horizon_component_count += valid_steps * 3.0

    trajectory_scores = {
        identifier: float(np.mean(values)) for identifier, values in by_trajectory.items()
    }
    return {
        "val_selection_score": float(np.mean(list(trajectory_scores.values()))),
        "val_selection_definition": "first-action normalized MSE, mean per trajectory then macro mean",
        "trajectory_first_action_normalized_mse": trajectory_scores,
        "masked_horizon_normalized_mse": masked_error_sum / max(masked_valid_steps, 1.0),
        "first_action_translation_rmse_mm": float(np.sqrt(np.mean(first_translation))),
        "first_action_rotation_rmse_deg": float(np.sqrt(np.mean(first_rotation))),
        "horizon_translation_rmse_mm": float(
            np.sqrt(horizon_translation_error_sum / max(horizon_component_count, 1.0))
        ),
        "horizon_rotation_rmse_deg": float(
            np.sqrt(horizon_rotation_error_sum / max(horizon_component_count, 1.0))
        ),
        "mean_inference_latency_ms": float(sum(latencies) / max(latency_samples, 1)),
        "inference_latency_definition": "model sampling latency per validation sample",
    }


def train_experiment(
    manifest_path: Path,
    split_path: Path,
    config: dict,
    output: Path,
    resume: bool = True,
) -> dict:
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    split = json.loads(Path(split_path).read_text(encoding="utf-8"))
    validate_split_payload(split)
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    validate_cache_manifest(manifest)
    if manifest.get("split_sha256") != split["split_sha256"]:
        raise ValueError("Cache was not built from the requested frozen split")
    completed_result = output / "result.json"
    if resume and completed_result.exists() and (output / "checkpoint_best.pt").exists():
        previous = json.loads(completed_result.read_text(encoding="utf-8"))
        if (
            previous.get("complete")
            and previous.get("config_digest") == config["config_digest"]
            and previous.get("split_sha256") == split["split_sha256"]
            and previous.get("cache_sha256") == manifest["cache_sha256"]
        ):
            saved_best = torch_load(output / "checkpoint_best.pt", map_location="cpu")
            if (
                saved_best.get("evaluation_weights") == "ema"
                and saved_best.get("config_digest") == config["config_digest"]
                and saved_best.get("split_sha256") == split["split_sha256"]
                and saved_best.get("cache_sha256") == manifest["cache_sha256"]
            ):
                return previous
    seed = int(config.get("training_seed", 42))
    set_global_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_dataset = PolicyDataset(manifest_path, set(split["train"]), config)
    validation_dataset = PolicyDataset(manifest_path, set(split["validation"]), config)
    loader_generator = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(
        train_dataset,
        batch_size=int(config.get("batch_size", 1)),
        shuffle=True,
        generator=loader_generator,
        collate_fn=collate_policy_samples,
        num_workers=int(config.get("workers", 0)),
        pin_memory=device.type == "cuda",
    )
    validation_loader = DataLoader(
        validation_dataset,
        batch_size=int(config.get("validation_batch_size", 1)),
        shuffle=False,
        collate_fn=collate_policy_samples,
        num_workers=int(config.get("workers", 0)),
    )
    policy = build_policy(config).to(device)
    ema_policy = initialize_ema_policy(policy, config, device)
    optimizer = torch.optim.AdamW(
        policy.parameters(),
        lr=float(config.get("learning_rate", 1e-4)),
        weight_decay=float(config.get("weight_decay", 1e-4)),
    )
    if config.get("lr_scheduler", "constant") == "cosine":
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=int(config.get("maximum_epochs", 100))
        )
    elif config.get("lr_scheduler", "constant") == "constant":
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda _: 1.0)
    else:
        raise ValueError("lr_scheduler must be 'constant' or 'cosine'")
    if hasattr(torch.amp, "GradScaler"):
        scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    else:
        scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")
    schedule = (
        CosineSchedule(int(config.get("diffusion_steps", DIFFUSION_STEPS)), device)
        if config["head"] == "diffusion"
        else None
    )
    latest_path = output / "checkpoint_last.pt"
    best_path = output / "checkpoint_best.pt"
    start_epoch = 0
    best_score = float("inf")
    best_epoch = 0
    checks_without_improvement = 0
    history = []

    if resume and latest_path.exists():
        saved = torch_load(latest_path, map_location="cpu")
        if saved.get("config_digest") != config["config_digest"]:
            raise ValueError("Resume checkpoint configuration does not match this experiment")
        if saved.get("split_sha256") != split["split_sha256"]:
            raise ValueError("Resume checkpoint frozen split does not match this experiment")
        if saved.get("cache_sha256") != manifest["cache_sha256"]:
            raise ValueError("Resume checkpoint cache does not match this experiment")
        if saved.get("evaluation_weights") != "ema":
            raise ValueError("Resume checkpoint must use EMA evaluation weights")
        policy.load_state_dict(saved["model_raw"])
        ema_policy.load_state_dict(saved["model_ema"])
        optimizer.load_state_dict(saved["optimizer"])
        scheduler.load_state_dict(saved["scheduler"])
        scaler.load_state_dict(saved["scaler"])
        if saved.get("loader_generator_state") is not None:
            loader_generator.set_state(saved["loader_generator_state"])
        start_epoch = int(saved["epoch"])
        best_score = float(saved["best_score"])
        best_epoch = int(saved["best_epoch"])
        checks_without_improvement = int(saved["checks_without_improvement"])
        history = list(saved["history"])
        _restore_rng_state(saved["rng_state"])

    maximum_epochs = int(config.get("maximum_epochs", 100))
    minimum_epochs = int(config.get("minimum_epochs", 10))
    patience = int(config.get("early_stopping_patience", 10))
    min_delta = float(config.get("early_stopping_min_delta", 1e-4))
    ema_decay = float(config.get("ema_decay", 0.995))
    started = time.perf_counter()
    early_stopped = False

    for epoch in range(start_epoch, maximum_epochs):
        policy.train()
        training_error_sum = 0.0
        training_valid_steps = 0.0
        for raw_batch in train_loader:
            batch = move_batch(raw_batch, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=device.type == "cuda",
            ):
                if config["head"] == "diffusion":
                    timestep = torch.randint(
                        0, schedule.steps, (len(batch["actions"]),), device=device
                    )
                    noisy = schedule.add_noise(
                        batch["actions"], timestep, torch.randn_like(batch["actions"])
                    )
                    prediction = policy(batch, noisy, timestep)
                else:
                    prediction = policy(batch)
                loss = masked_mse(prediction, batch["actions"], batch["mask"])
            if not torch.isfinite(loss):
                raise FloatingPointError(
                    f"Non-finite training loss at epoch {epoch + 1}"
                )
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            with torch.no_grad():
                for ema_parameter, parameter in zip(ema_policy.parameters(), policy.parameters()):
                    ema_parameter.lerp_(parameter, 1.0 - ema_decay)
                for ema_buffer, buffer in zip(ema_policy.buffers(), policy.buffers()):
                    ema_buffer.copy_(buffer)
            valid_steps = float(batch["mask"].sum().item())
            training_error_sum += float(loss.item()) * valid_steps
            training_valid_steps += valid_steps

        scheduler.step()

        metrics = evaluate_model(ema_policy, config, validation_loader, device)
        score = metrics["val_selection_score"]
        if not np.isfinite(score):
            raise FloatingPointError(f"Non-finite validation score at epoch {epoch + 1}: {score}")
        improved = score < best_score - min_delta
        if improved:
            best_score = score
            best_epoch = epoch + 1
            checks_without_improvement = 0
        else:
            checks_without_improvement += 1
        record = {
            "epoch": epoch + 1,
            "train_masked_normalized_mse": training_error_sum / max(training_valid_steps, 1.0),
            **metrics,
            "best_epoch": best_epoch,
            "best_score": best_score,
            "checks_without_improvement": checks_without_improvement,
        }
        history.append(record)
        checkpoint = {
            "schema": EXPERIMENT_SCHEMA,
            "config": config,
            "config_digest": config["config_digest"],
            "split_sha256": split["split_sha256"],
            "cache_sha256": manifest["cache_sha256"],
            "manifest_path": str(Path(manifest_path).resolve()),
            "split_path": str(Path(split_path).resolve()),
            "evaluation_weights": "ema",
            "objective": "diffusion_clean_action" if config["head"] == "diffusion" else "deterministic_action_chunk",
            "model_raw": policy.state_dict(),
            "model_ema": ema_policy.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": scaler.state_dict(),
            "loader_generator_state": loader_generator.get_state(),
            "epoch": epoch + 1,
            "best_epoch": best_epoch,
            "best_score": best_score,
            "checks_without_improvement": checks_without_improvement,
            "history": history,
            "split": split,
            "rng_state": _rng_state(),
        }
        _atomic_torch_save(latest_path, checkpoint)
        if improved:
            _atomic_torch_save(best_path, checkpoint)
        write_json_atomic(output / "history.json", history)
        print(json.dumps(record), flush=True)
        if epoch + 1 >= minimum_epochs and checks_without_improvement >= patience:
            early_stopped = True
            break

    if not best_path.is_file():
        raise RuntimeError("Training ended without a finite best checkpoint")
    best_saved = torch_load(best_path, map_location="cpu")
    best_metrics = best_saved["history"][-1]
    result = {
        "experiment_name": config["experiment_name"],
        "config_digest": config["config_digest"],
        "checkpoint": str(best_path),
        "epochs_completed": len(history),
        "best_epoch": best_epoch,
        "best_validation_score": best_score,
        "best_metrics": best_metrics,
        "early_stopped": early_stopped,
        "early_stopping_counter": checks_without_improvement,
        "training_samples": len(train_dataset),
        "validation_samples": len(validation_dataset),
        "elapsed_minutes_this_run": (time.perf_counter() - started) / 60.0,
        "device": str(device),
        "evaluation_weights": "ema",
        "split_sha256": split["split_sha256"],
        "cache_sha256": manifest["cache_sha256"],
        "complete": True,
    }
    write_json_atomic(output / "result.json", result)
    return result


def validate_checkpoint(
    checkpoint_path: Path,
    manifest_path: Path,
    split_path: Path,
    output_path: Path | None = None,
) -> dict:
    saved = torch_load(Path(checkpoint_path), map_location="cpu")
    config = saved["config"]
    if saved.get("evaluation_weights") != "ema":
        raise ValueError("Final validation is required to use EMA weights")
    split = json.loads(Path(split_path).read_text(encoding="utf-8"))
    validate_split_payload(split)
    if saved.get("split_sha256") != split["split_sha256"]:
        raise ValueError("Checkpoint split hash does not match validation split")
    dataset = PolicyDataset(manifest_path, set(split["validation"]), config)
    if saved.get("cache_sha256") != dataset.cache_sha256:
        raise ValueError("Checkpoint cache hash does not match validation cache")
    loader = DataLoader(
        dataset,
        batch_size=int(config.get("validation_batch_size", 1)),
        shuffle=False,
        collate_fn=collate_policy_samples,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    policy = build_policy(config).to(device).eval()
    weights = saved["model_ema"] if saved.get("evaluation_weights") == "ema" else saved["model_raw"]
    policy.load_state_dict(weights)
    result = {
        "checkpoint": str(Path(checkpoint_path).resolve()),
        "weights": saved.get("evaluation_weights", "raw"),
        "config_digest": saved["config_digest"],
        "split_sha256": saved["split_sha256"],
        "cache_sha256": saved["cache_sha256"],
        **evaluate_model(policy, config, loader, device),
    }
    if output_path is not None:
        write_json_atomic(Path(output_path), result)
    return result


@torch.inference_mode()
def export_offline_predictions(
    checkpoint_path: Path,
    manifest_path: Path,
    split_path: Path,
    output_path: Path,
) -> dict:
    saved = torch_load(Path(checkpoint_path), map_location="cpu")
    config = saved["config"]
    if saved.get("evaluation_weights") != "ema":
        raise ValueError("Offline inference is required to use EMA weights")
    split = json.loads(Path(split_path).read_text(encoding="utf-8"))
    validate_split_payload(split)
    if saved.get("split_sha256") != split["split_sha256"]:
        raise ValueError("Checkpoint split hash does not match inference split")
    dataset = PolicyDataset(manifest_path, set(split["validation"]), config)
    if saved.get("cache_sha256") != dataset.cache_sha256:
        raise ValueError("Checkpoint cache hash does not match inference cache")
    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_policy_samples)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    policy = build_policy(config).to(device).eval()
    policy.load_state_dict(saved["model_ema"] if saved.get("evaluation_weights") == "ema" else saved["model_raw"])
    schedule = CosineSchedule(int(config.get("diffusion_steps", 100)), device) if config["head"] == "diffusion" else None
    generator = torch.Generator(device=device).manual_seed(int(config.get("validation_seed", 42)))
    scale = torch.tensor(config["action_scale"], device=device)
    rows = []
    for raw_batch in loader:
        batch = move_batch(raw_batch, device)
        with torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=device.type == "cuda",
        ):
            prediction = predict_actions(
                policy,
                schedule,
                batch,
                int(config.get("inference_steps", 20)),
                generator,
            )
        rows.append(
            {
                "trajectory_id": raw_batch["trajectory_id"][0],
                "state": int(raw_batch["state"][0]),
                "predicted_action_chunk_mm_deg": (prediction[0] * scale).cpu().tolist(),
                "predicted_normalized_action_chunk": prediction[0].cpu().tolist(),
                "recorded_action_chunk_mm_deg": (batch["actions"][0] * scale).cpu().tolist(),
                "valid_action_mask": batch["mask"][0].cpu().tolist(),
            }
        )
    payload = {
        "checkpoint": str(Path(checkpoint_path).resolve()),
        "config_digest": saved["config_digest"],
        "split_sha256": saved["split_sha256"],
        "cache_sha256": saved["cache_sha256"],
        "evaluation_weights": "ema",
        "output_shape_per_state": [int(config["prediction_window"]), 6],
        "predictions": rows,
    }
    write_json_atomic(Path(output_path), payload)
    return payload
