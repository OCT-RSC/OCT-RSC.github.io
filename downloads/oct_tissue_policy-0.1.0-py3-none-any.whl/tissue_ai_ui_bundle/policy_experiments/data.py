from __future__ import annotations

"""Trajectory discovery, audit, frozen splitting, caching, and dataset loading."""

import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from scipy.spatial.transform import Rotation
from torch.utils.data import Dataset

from tissue_ai_ui_bundle.physical_policy.real_data import action_array, numeric_steps

from .config import CACHE_SCHEMA, canonical_json, config_digest, write_json_atomic
from .representations import RepresentationProcessor


def _within_prefixes(
    trajectory: Path,
    data_root: Path,
    include_prefixes: tuple[str, ...] | list[str] | None,
) -> bool:
    if not include_prefixes:
        return True
    identifier = trajectory_id(trajectory, data_root)
    prefixes = [str(prefix).replace("\\", "/").strip("/") for prefix in include_prefixes]
    return any(identifier == prefix or identifier.startswith(f"{prefix}/") for prefix in prefixes)


def discover_trajectories(
    data_root: Path,
    material: str | None = None,
    include_prefixes: tuple[str, ...] | list[str] | None = None,
) -> list[Path]:
    """Discover only complete demonstrations that own target metadata."""
    data_root = Path(data_root).resolve()
    trajectories: list[Path] = []
    for selection in data_root.rglob("target_selection.json"):
        predeform = selection.parent
        if predeform.name != "predeform":
            continue
        trajectory = predeform.parent
        try:
            metadata = json.loads(selection.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if material is not None and metadata.get("material") != material:
            continue
        if not _within_prefixes(trajectory, data_root, include_prefixes):
            continue
        if (predeform / "ascans.npy").exists() and numeric_steps(trajectory):
            trajectories.append(trajectory)
    return sorted(set(trajectories), key=lambda path: str(path.relative_to(data_root)))


def trajectory_id(trajectory: Path, data_root: Path) -> str:
    return Path(trajectory).resolve().relative_to(Path(data_root).resolve()).as_posix()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def split_digest(split: dict) -> str:
    payload = {key: value for key, value in split.items() if key != "split_sha256"}
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def validate_split_payload(split: dict) -> None:
    recorded = split.get("split_sha256")
    computed = split_digest(split)
    if recorded != computed:
        raise ValueError(f"Split hash mismatch: recorded={recorded}, computed={computed}")
    overlap = set(split["train"]) & set(split["validation"])
    if overlap:
        raise ValueError(f"Trajectory leakage across split: {sorted(overlap)}")


def cache_manifest_digest(manifest: dict) -> str:
    payload = {key: value for key, value in manifest.items() if key != "cache_sha256"}
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def validate_cache_manifest(manifest: dict) -> None:
    if manifest.get("schema") != CACHE_SCHEMA:
        raise ValueError(f"Expected cache schema {CACHE_SCHEMA}")
    recorded = manifest.get("cache_sha256")
    computed = cache_manifest_digest(manifest)
    if recorded != computed:
        raise ValueError(
            f"Cache manifest hash mismatch: recorded={recorded}, computed={computed}"
        )


def _resolve_cached_path(path: str | Path, manifest_dir: Path) -> Path:
    cached = Path(path)
    return cached if cached.is_absolute() else manifest_dir / cached


def validate_cache_files(
    manifest: dict,
    trajectory_ids: set[str] | None = None,
    manifest_path: Path | None = None,
) -> dict:
    """Verify cached representation bytes against the content-bound manifest."""
    manifest_dir = (
        Path(manifest_path).resolve().parent
        if manifest_path is not None
        else Path.cwd()
    )
    checked = 0
    for trajectory in manifest["trajectories"]:
        if trajectory_ids is not None and trajectory["id"] not in trajectory_ids:
            continue
        paths = [*trajectory["observations"], trajectory["target"]]
        hashes = [*trajectory["observation_sha256"], trajectory["target_sha256"]]
        for path, expected in zip(paths, hashes):
            cached = _resolve_cached_path(path, manifest_dir)
            if not cached.is_file():
                raise FileNotFoundError(f"Cached representation is missing: {cached}")
            actual = _sha256_file(cached)
            if actual != expected:
                raise ValueError(
                    f"Cached representation hash mismatch for {cached}: "
                    f"recorded={expected}, computed={actual}"
                )
            checked += 1
    return {"verified_files": checked, "cache_sha256": manifest["cache_sha256"]}


def _target_path(trajectory: Path) -> Path:
    for path in (
        trajectory / "predeform" / "target_volume.npy",
        trajectory / "target_volume.npy",
    ):
        if path.exists():
            return path
    raise FileNotFoundError(f"No target_volume.npy in {trajectory}")


def action_transform(action: np.ndarray) -> np.ndarray:
    """Convert local delta XYZ mm and Euler-XYZ degrees to a 4x4 transform."""
    action = np.asarray(action, dtype=np.float64)
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = Rotation.from_euler(
        "xyz", action[3:], degrees=True
    ).as_matrix()
    transform[:3, 3] = action[:3] / 1000.0
    return transform


def _pose_and_action_records(trajectory: Path) -> tuple[list[np.ndarray], np.ndarray]:
    steps = numeric_steps(trajectory)
    records = [json.loads((step / "step_info.json").read_text(encoding="utf-8")) for step in steps]
    actions = np.stack([action_array(record) for record in records]).astype(np.float32)
    poses_after = [
        np.asarray(record["tooltip_transform_4x4"], dtype=np.float64)
        for record in records
    ]
    initial = poses_after[0] @ np.linalg.inv(action_transform(actions[0]))
    return [initial, *poses_after], actions


def relative_tool_pose(initial: np.ndarray, current: np.ndarray) -> np.ndarray:
    relative = np.linalg.inv(initial) @ current
    xyz_mm = relative[:3, 3] * 1000.0
    rotation_deg = np.rad2deg(Rotation.from_matrix(relative[:3, :3]).as_rotvec())
    return np.concatenate((xyz_mm, rotation_deg)).astype(np.float32)


def audit_dataset(
    data_root: Path,
    output: Path | None = None,
    include_prefixes: tuple[str, ...] | list[str] | None = None,
) -> dict:
    """Check the real on-disk trajectory contract without loading whole volumes."""
    root = Path(data_root).resolve()
    records = []
    errors = []
    for trajectory in discover_trajectories(root, include_prefixes=include_prefixes):
        identifier = trajectory_id(trajectory, root)
        try:
            selection = json.loads(
                (trajectory / "predeform" / "target_selection.json").read_text(
                    encoding="utf-8"
                )
            )
            steps = numeric_steps(trajectory)
            sources = [trajectory / "predeform" / "ascans.npy"] + [
                step / "ascans.npy" for step in steps
            ]
            target = _target_path(trajectory)
            descriptors = []
            for path in [*sources, target]:
                array = np.load(path, mmap_mode="r")
                descriptors.append(
                    {"path": str(path), "shape": list(array.shape), "dtype": str(array.dtype)}
                )
            shapes = {tuple(item["shape"]) for item in descriptors}
            dtypes = {item["dtype"] for item in descriptors}
            if len(shapes) != 1:
                raise ValueError(f"OCT/target shapes differ: {sorted(shapes)}")
            if next(iter(shapes)) not in ((1, 256, 256, 768, 1), (256, 256, 768)):
                raise ValueError(f"Unexpected OCT shape: {next(iter(shapes))}")
            if dtypes != {"int8"}:
                raise ValueError(f"Expected int8 OCT/target data, found {sorted(dtypes)}")
            poses, actions = _pose_and_action_records(trajectory)
            if len(poses) != len(actions) + 1:
                raise ValueError("Pose/action state contract is inconsistent")
            if not np.isfinite(actions).all() or not np.isfinite(np.stack(poses)).all():
                raise ValueError("Pose/action data contain non-finite values")
            maximum_translation_error_mm = 0.0
            maximum_rotation_error_deg = 0.0
            for index, action in enumerate(actions):
                expected = poses[index] @ action_transform(action)
                difference = np.linalg.inv(expected) @ poses[index + 1]
                maximum_translation_error_mm = max(
                    maximum_translation_error_mm,
                    float(np.linalg.norm(difference[:3, 3]) * 1000.0),
                )
                maximum_rotation_error_deg = max(
                    maximum_rotation_error_deg,
                    float(
                        np.rad2deg(
                            np.linalg.norm(
                                Rotation.from_matrix(difference[:3, :3]).as_rotvec()
                            )
                        )
                    ),
                )
            if maximum_translation_error_mm >= 1e-6 or maximum_rotation_error_deg >= 1e-6:
                raise ValueError(
                    "Saved local action and tooltip pose directions are inconsistent: "
                    f"translation={maximum_translation_error_mm} mm, "
                    f"rotation={maximum_rotation_error_deg} deg"
                )
            records.append(
                {
                    "id": identifier,
                    "material": selection.get("material"),
                    "group": trajectory.parent.name,
                    "steps": len(steps),
                    "volumes": descriptors,
                    "target_selection": str(trajectory / "predeform" / "target_selection.json"),
                    "pose_action_alignment": {
                        "definition": "pose[t+1] == pose[t] @ local_delta_xyz_mm_euler_xyz_deg",
                        "maximum_translation_error_mm": maximum_translation_error_mm,
                        "maximum_rotation_error_deg": maximum_rotation_error_deg,
                    },
                }
            )
        except Exception as error:
            errors.append({"id": identifier, "error": f"{type(error).__name__}: {error}"})
    summary = {
        "data_root": str(root),
        "include_prefixes": list(include_prefixes or []),
        "trajectory_count": len(records),
        "error_count": len(errors),
        "material_counts": {
            name: sum(record["material"] == name for record in records)
            for name in sorted({record["material"] for record in records})
        },
        "trajectories": records,
        "errors": errors,
    }
    if output is not None:
        write_json_atomic(Path(output), summary)
    return summary


def create_frozen_split(
    data_root: Path,
    material: str,
    output: Path,
    validation_fraction: float = 0.2,
    seed: int = 42,
    include_prefixes: tuple[str, ...] | list[str] | None = None,
) -> dict:
    """Create one group-stratified split reused by every representation/head."""
    root = Path(data_root).resolve()
    grouped: dict[str, list[str]] = defaultdict(list)
    for trajectory in discover_trajectories(root, material, include_prefixes):
        grouped[trajectory.parent.name].append(trajectory_id(trajectory, root))
    if not grouped:
        raise RuntimeError(f"No {material} demonstrations found in {root}")

    rng = random.Random(int(seed))
    train_ids: list[str] = []
    validation_ids: list[str] = []
    groups = {}
    for group, identifiers in sorted(grouped.items()):
        shuffled = sorted(identifiers)
        rng.shuffle(shuffled)
        validation_count = max(1, int(round(len(shuffled) * validation_fraction)))
        validation = sorted(shuffled[:validation_count])
        train = sorted(shuffled[validation_count:])
        train_ids.extend(train)
        validation_ids.extend(validation)
        groups[group] = {"train": train, "validation": validation}
    payload = {
        "schema": "trajectory_split_v1",
        "data_root": str(root),
        "material": material,
        "split_seed": int(seed),
        "validation_fraction": float(validation_fraction),
        "include_prefixes": list(include_prefixes or []),
        "train": sorted(train_ids),
        "validation": sorted(validation_ids),
        "groups": groups,
    }
    payload["split_sha256"] = split_digest(payload)
    write_json_atomic(Path(output), payload)
    return payload


def _cache_extension(representation: str) -> str:
    return ".npy" if representation in ("full_volume", "point_cloud") else ".npz"


def _cached_descriptor(path: Path, representation: str) -> dict:
    if representation == "tissue_only":
        saved = np.load(path)
        coordinates = saved["coordinates"]
        features = saved["features"]
        return {
            "coordinates_shape": list(coordinates.shape),
            "features_shape": list(features.shape),
            "active_voxels": int(len(coordinates)),
            "coordinate_min_dhw": coordinates.min(axis=0).tolist(),
            "coordinate_max_dhw": coordinates.max(axis=0).tolist(),
            "finite": bool(np.isfinite(features).all()),
        }
    array = np.load(path, mmap_mode="r")
    return {
        "shape": list(array.shape),
        "dtype": str(array.dtype),
        "finite": bool(np.isfinite(array).all()),
    }


def representation_cache_spec(config: dict) -> dict:
    """Only fields that can change a cached, non-learned representation."""
    names = (
        "material",
        "representation",
        "dense_resolution",
        "sparse_resolution",
        "point_count",
        "tissue_threshold",
        "air_sigma_multiplier",
        "maximum_visible_tissue_depth_mm",
        "mask_top_margin",
        "mask_bottom_margin",
        "mask_gap_fill_voxels",
        "minimum_visible_tissue_depth_voxels",
        "target_representation_source",
        "representation_seed",
    )
    return {name: config[name] for name in names if name in config}


def build_cache(
    data_root: Path,
    split_path: Path,
    config: dict,
    output_root: Path,
    overwrite: bool = False,
) -> Path:
    """Cache non-learned representations while preserving source provenance."""
    root = Path(data_root).resolve()
    split = json.loads(Path(split_path).read_text(encoding="utf-8"))
    validate_split_payload(split)
    if split["material"] != config["material"]:
        raise ValueError("Split material does not match experiment material")
    wanted = set(split["train"]) | set(split["validation"])
    cache_spec = representation_cache_spec(config)
    cache_spec_digest = config_digest(cache_spec)
    cache_key = f"{config['material']}__{config['representation']}__{cache_spec_digest}"
    cache = Path(output_root).resolve() / cache_key
    cache.mkdir(parents=True, exist_ok=True)
    extension = _cache_extension(config["representation"])
    manifest = {
        "schema": CACHE_SCHEMA,
        "cache_key": cache_key,
        "representation_config": cache_spec,
        "representation_config_digest": cache_spec_digest,
        "data_root": str(root),
        "split": str(Path(split_path).resolve()),
        "split_sha256": split["split_sha256"],
        "material": config["material"],
        "representation": config["representation"],
        "preprocessing": {
            "coordinate_frame": "scanner-fixed DHW with existing X flip",
            "full_volume": "existing floor-aware cleanup, normalization, and resize",
            "tissue_mask": "artifact-cleaned complete visible tissue mask",
            "target_mask": "complete visible-tissue mask extracted from the saved target volume",
            "point_cloud": "1024 physical XYZ points from the target-volume tissue mask",
        },
        "trajectories": [],
    }

    by_id = {
        trajectory_id(path, root): path
        for path in discover_trajectories(root, config["material"])
    }
    for identifier in sorted(wanted):
        if identifier not in by_id:
            raise FileNotFoundError(f"Split trajectory is missing: {identifier}")
        trajectory = by_id[identifier]
        processor = RepresentationProcessor(trajectory, config)
        safe_name = hashlib.sha256(identifier.encode("utf-8")).hexdigest()[:12]
        destination = cache / safe_name
        destination.mkdir(exist_ok=True)
        steps = numeric_steps(trajectory)
        sources = [trajectory / "predeform" / "ascans.npy"] + [
            step / "ascans.npy" for step in steps
        ]
        observations: list[str] = []
        observation_paths: list[Path] = []
        for state, source in enumerate(sources):
            cached = destination / f"observation_{state:03d}{extension}"
            if overwrite or not cached.exists():
                processor.save_representation(source, cached, is_target=False, state=state)
            observation_paths.append(cached)
            observations.append(cached.relative_to(cache).as_posix())
        target_source = _target_path(trajectory)
        cached_target = destination / f"target{extension}"
        if overwrite or not cached_target.exists():
            processor.save_representation(target_source, cached_target, is_target=True, state=-1)

        poses, actions = _pose_and_action_records(trajectory)
        initial = poses[0]
        tool_scale = np.asarray(config["tool_scale"], dtype=np.float32)
        tool_poses = [
            (relative_tool_pose(initial, pose) / tool_scale).tolist() for pose in poses
        ]
        observation_hashes = [_sha256_file(path) for path in observation_paths]
        observation_descriptors = [
            _cached_descriptor(path, config["representation"])
            for path in observation_paths
        ]
        target_hash = _sha256_file(cached_target)
        target_descriptor = _cached_descriptor(cached_target, config["representation"])
        manifest["trajectories"].append(
            {
                "id": identifier,
                "source": identifier,
                "group": trajectory.parent.name,
                "observations": observations,
                "observation_sha256": observation_hashes,
                "observation_descriptors": observation_descriptors,
                "target": cached_target.relative_to(cache).as_posix(),
                "target_sha256": target_hash,
                "target_descriptor": target_descriptor,
                "target_source": target_source.relative_to(root).as_posix(),
                "tool_poses": tool_poses,
                "actions": actions.tolist(),
            }
        )
        print(f"cached {identifier}: {len(actions)} actions", flush=True)
    manifest["cache_sha256"] = cache_manifest_digest(manifest)
    manifest_path = cache / "manifest.json"
    write_json_atomic(manifest_path, manifest)
    return manifest_path


def _load_representation(path: str, representation: str):
    if representation in ("full_volume", "point_cloud"):
        return torch.from_numpy(np.asarray(np.load(path), dtype=np.float32))
    saved = np.load(path)
    return {
        "coordinates": torch.from_numpy(saved["coordinates"].astype(np.int32)),
        "features": torch.from_numpy(saved["features"].astype(np.float32)),
    }


class PolicyDataset(Dataset):
    """One sample per demonstrated action; incomplete future tails are masked."""

    def __init__(self, manifest_path: Path, trajectory_ids: set[str], config: dict):
        manifest_path = Path(manifest_path).resolve()
        self.manifest_dir = manifest_path.parent
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        validate_cache_manifest(manifest)
        expected_spec_digest = config_digest(representation_cache_spec(config))
        if manifest.get("representation_config_digest") != expected_spec_digest:
            raise ValueError("Cache representation configuration does not match the model config")
        if manifest.get("material") != config["material"]:
            raise ValueError("Cache material does not match the model config")
        if manifest.get("representation") != config["representation"]:
            raise ValueError("Cache representation does not match the model config")
        self.cache_sha256 = manifest["cache_sha256"]
        self.config = config
        self.representation = config["representation"]
        self.history = int(config["observation_window"])
        self.horizon = int(config["prediction_window"])
        self.action_scale = torch.tensor(config["action_scale"], dtype=torch.float32)
        self.trajectories = {
            item["id"]: item
            for item in manifest["trajectories"]
            if item["id"] in trajectory_ids
        }
        missing = set(trajectory_ids) - set(self.trajectories)
        if missing:
            raise FileNotFoundError(f"Trajectories missing from cache: {sorted(missing)}")
        self._expected_file_hashes = {}
        for trajectory in self.trajectories.values():
            for path, digest in zip(
                trajectory["observations"], trajectory["observation_sha256"]
            ):
                self._expected_file_hashes[path] = digest
            self._expected_file_hashes[trajectory["target"]] = trajectory["target_sha256"]
        self._loaded_representations = {}
        self.samples = [
            (identifier, state)
            for identifier, trajectory in self.trajectories.items()
            for state in range(len(trajectory["actions"]))
        ]

    def __len__(self) -> int:
        return len(self.samples)

    def _load_verified(self, path: str):
        if path not in self._loaded_representations:
            expected = self._expected_file_hashes[path]
            resolved = _resolve_cached_path(path, self.manifest_dir)
            actual = _sha256_file(resolved)
            if actual != expected:
                raise ValueError(
                    f"Cached representation checksum mismatch for {path}: "
                    f"expected={expected}, actual={actual}"
                )
            self._loaded_representations[path] = _load_representation(
                str(resolved), self.representation
            )
        return self._loaded_representations[path]

    def __getitem__(self, index: int) -> dict:
        identifier, state = self.samples[index]
        trajectory = self.trajectories[identifier]
        history_indices = [max(0, state - self.history + 1 + offset) for offset in range(self.history)]
        observations = [
            self._load_verified(trajectory["observations"][item])
            for item in history_indices
        ]
        target = self._load_verified(trajectory["target"])
        tool_poses = torch.tensor(
            [trajectory["tool_poses"][item] for item in history_indices],
            dtype=torch.float32,
        )
        actions = torch.zeros(self.horizon, 6, dtype=torch.float32)
        mask = torch.zeros(self.horizon, dtype=torch.float32)
        future = trajectory["actions"][state : state + self.horizon]
        if future:
            actions[: len(future)] = torch.tensor(future, dtype=torch.float32) / self.action_scale
            mask[: len(future)] = 1.0
        return {
            "observations": observations,
            "target": target,
            "tool_poses": tool_poses,
            "actions": actions,
            "mask": mask,
            "trajectory_id": identifier,
            "state": state,
        }


def collate_policy_samples(samples: list[dict]) -> dict:
    representation = "sparse" if isinstance(samples[0]["target"], dict) else "dense"
    if representation == "sparse":
        observations = [sample["observations"] for sample in samples]
        target = [sample["target"] for sample in samples]
    else:
        observations = torch.stack(
            [torch.stack(sample["observations"]) for sample in samples]
        )
        target = torch.stack([sample["target"] for sample in samples])
    return {
        "observations": observations,
        "target": target,
        "tool_poses": torch.stack([sample["tool_poses"] for sample in samples]),
        "actions": torch.stack([sample["actions"] for sample in samples]),
        "mask": torch.stack([sample["mask"] for sample in samples]),
        "trajectory_id": [sample["trajectory_id"] for sample in samples],
        "state": torch.tensor([sample["state"] for sample in samples]),
    }
