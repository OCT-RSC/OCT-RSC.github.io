from __future__ import annotations

"""Configuration validation shared by preprocessing, training, and inference."""

import hashlib
import json
from pathlib import Path

import torch


EXPERIMENT_SCHEMA = "oct_policy_three_input_v1"
CACHE_SCHEMA = "oct_policy_representation_cache_v2"
REPRESENTATIONS = ("full_volume", "tissue_only", "point_cloud")
HEADS = ("diffusion", "deterministic_bc")
MATERIALS = ("phantom", "exvivo")


def canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def config_digest(config: dict) -> str:
    return hashlib.sha256(canonical_json(config).encode("utf-8")).hexdigest()[:16]


def validate_config(config: dict) -> dict:
    config = dict(config)
    if config.get("schema") != EXPERIMENT_SCHEMA:
        raise ValueError(f"Expected schema {EXPERIMENT_SCHEMA!r}")
    if config.get("material") not in MATERIALS:
        raise ValueError(f"material must be one of {MATERIALS}")
    if config.get("representation") not in REPRESENTATIONS:
        raise ValueError(f"representation must be one of {REPRESENTATIONS}")
    if config.get("head") not in HEADS:
        raise ValueError(f"head must be one of {HEADS}")
    if not isinstance(config.get("use_residual"), bool):
        raise ValueError("use_residual must be boolean")
    if config.get("target_representation_source") != "target_volume":
        raise ValueError(
            "All model target representations must be derived from target_volume.npy"
        )
    for name in ("observation_window", "prediction_window", "execute_window"):
        if int(config[name]) <= 0:
            raise ValueError(f"{name} must be positive")
    if int(config["execute_window"]) > int(config["prediction_window"]):
        raise ValueError("execute_window cannot exceed prediction_window")
    required_integer_values = {
        "observation_window": 3,
        "prediction_window": 8,
        "execute_window": 1,
        "embedding_dim": 128,
        "diffusion_steps": 100,
        "inference_steps": 20,
        "training_seed": 42,
        "validation_seed": 42,
        "inference_seed": 42,
        "split_seed": 42,
        "representation_seed": 42,
        "maximum_epochs": 100,
        "minimum_epochs": 10,
        "early_stopping_patience": 10,
    }
    for name, expected in required_integer_values.items():
        if int(config.get(name, -1)) != expected:
            raise ValueError(f"{name} must be {expected} for the fixed experiment matrix")
    if list(config.get("spatial_grid", [])) != [4, 4, 4]:
        raise ValueError("Dense spatial_grid must be [4,4,4]")
    for name in ("action_scale", "tool_scale"):
        values = config[name]
        if len(values) != 6 or any(float(value) <= 0 for value in values):
            raise ValueError(f"{name} must contain six positive values")
    if config["representation"] == "full_volume":
        resolution = config.get("dense_resolution")
        if resolution != [256, 256, 256]:
            raise ValueError("full_volume requires dense_resolution=[256,256,256] DHW")
    if config["representation"] == "tissue_only":
        resolution = config.get("sparse_resolution")
        if resolution != [72, 128, 128]:
            raise ValueError("tissue_only requires sparse_resolution=[72,128,128] DHW")
        if config.get("sparse_backend") != "native_pytorch":
            raise ValueError("tissue_only requires sparse_backend=native_pytorch")
        if config.get("sparse_backend_version") != "native_sparse_cnn_v1":
            raise ValueError(
                "tissue_only requires sparse_backend_version=native_sparse_cnn_v1"
            )
    if config["representation"] == "point_cloud":
        if int(config.get("point_count", 0)) != 1024:
            raise ValueError("point_cloud uses exactly 1024 non-padding tissue points")
    if [float(value) for value in config["action_scale"]] != [2.0] * 6:
        raise ValueError("action_scale must be [2,2,2,2,2,2]")
    required_float_values = {
        "learning_rate": 1e-4,
        "weight_decay": 1e-4,
        "ema_decay": 0.995,
        "early_stopping_min_delta": 1e-4,
    }
    for name, expected in required_float_values.items():
        if float(config.get(name, float("nan"))) != expected:
            raise ValueError(f"{name} must be {expected} for the fixed experiment matrix")
    config["config_digest"] = config_digest(
        {key: value for key, value in config.items() if key != "config_digest"}
    )
    return config


def _load_config_dict(path: Path) -> dict:
    path = Path(path).resolve()
    value = json.loads(path.read_text(encoding="utf-8"))
    base_name = value.pop("extends", None)
    if base_name is not None:
        base = _load_config_dict(path.parent / base_name)
        base.update(value)
        value = base
    return value


def load_config(path: Path) -> dict:
    """Load one experiment JSON with an optional relative base config."""
    path = Path(path).resolve()
    value = _load_config_dict(path)
    value = validate_config(value)
    value["config_path"] = str(path)
    value["config_digest"] = config_digest(
        {key: item for key, item in value.items() if key not in ("config_path", "config_digest")}
    )
    return value


def write_json_atomic(path: Path, value: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)


def torch_load(path: Path, map_location="cpu"):
    """Load full training state across PyTorch's weights_only default change."""
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)
