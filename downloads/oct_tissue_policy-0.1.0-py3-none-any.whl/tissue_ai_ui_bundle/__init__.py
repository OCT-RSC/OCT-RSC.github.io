"""Checkpoint-compatible implementation of the OCT tissue-control policies."""

