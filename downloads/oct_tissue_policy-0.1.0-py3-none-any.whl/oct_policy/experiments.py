from __future__ import annotations

"""Experiment discovery for the public OCT policy package.

The checkpoint-compatible implementation keeps its historical package name,
but callers should not need to know that layout. This module gives the CLI and
external users a small, stable way to discover the released experiment files.
"""

from pathlib import Path
import json


def experiment_directory() -> Path:
    """Return the directory containing the released experiment JSON files."""

    return (
        Path(__file__).resolve().parents[1]
        / "tissue_ai_ui_bundle"
        / "policy_experiments"
        / "configs"
    )


def matrix_directory() -> Path:
    """Return the directory containing installed paper experiment matrices."""

    return Path(__file__).resolve().parent / "matrices"


def data_profile_directory() -> Path:
    """Return the directory containing installed dataset selections."""

    return Path(__file__).resolve().parent / "data_profiles"


def available_experiments() -> tuple[str, ...]:
    """List experiment names accepted by :func:`resolve_experiment`."""

    return tuple(
        path.stem
        for path in sorted(experiment_directory().glob("*.json"))
        if path.name != "base.json"
    )


def resolve_experiment(value: str | Path) -> Path:
    """Resolve either an experiment name or an explicit JSON path."""

    candidate = Path(value).expanduser()
    if candidate.is_file():
        return candidate.resolve()

    name = candidate.stem if candidate.suffix == ".json" else str(candidate)
    bundled = experiment_directory() / f"{name}.json"
    if bundled.is_file():
        return bundled.resolve()

    choices = ", ".join(available_experiments())
    raise FileNotFoundError(f"Unknown experiment {value!r}. Available: {choices}")


def _read_with_base(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    base_name = value.pop("extends", None)
    if base_name is None:
        return value
    base = _read_with_base(path.parent / base_name)
    base.update(value)
    return base


def describe_experiments() -> list[dict]:
    """Return the model choices of every bundled experiment without loading PyTorch."""

    descriptions = []
    for name in available_experiments():
        config = _read_with_base(resolve_experiment(name))
        descriptions.append(
            {
                "name": name,
                "material": config["material"],
                "representation": config["representation"],
                "residual": bool(config["use_residual"]),
                "head": config["head"],
            }
        )
    return descriptions


def available_matrices() -> tuple[str, ...]:
    return tuple(path.stem for path in sorted(matrix_directory().glob("*.json")))


def resolve_matrix(value: str | Path) -> Path:
    """Resolve either a bundled matrix name or an explicit JSON path."""

    candidate = Path(value).expanduser()
    if candidate.is_file():
        return candidate.resolve()
    name = candidate.stem if candidate.suffix == ".json" else str(candidate)
    bundled = matrix_directory() / f"{name}.json"
    if bundled.is_file():
        return bundled.resolve()
    choices = ", ".join(available_matrices())
    raise FileNotFoundError(f"Unknown experiment matrix {value!r}. Available: {choices}")


def available_data_profiles() -> tuple[str, ...]:
    """List installed raw-data selections accepted by public workflows."""

    return tuple(
        path.stem for path in sorted(data_profile_directory().glob("*.json"))
    )


def resolve_data_profile(value: str | Path) -> Path:
    """Resolve either an installed data-profile name or an explicit JSON path."""

    candidate = Path(value).expanduser()
    if candidate.is_file():
        return candidate.resolve()
    name = candidate.stem if candidate.suffix == ".json" else str(candidate)
    bundled = data_profile_directory() / f"{name}.json"
    if bundled.is_file():
        return bundled.resolve()
    choices = ", ".join(available_data_profiles())
    raise FileNotFoundError(f"Unknown data profile {value!r}. Available: {choices}")
