from __future__ import annotations

"""Runtime provenance recorded beside each reproduction run."""

from importlib.metadata import PackageNotFoundError, version
import platform
import sys

import torch


def _version(distribution: str) -> str | None:
    try:
        return version(distribution)
    except PackageNotFoundError:
        return None


def environment_summary() -> dict:
    """Return package, Python, operating-system, and accelerator versions."""

    cuda_available = torch.cuda.is_available()
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": {
            "numpy": _version("numpy"),
            "scipy": _version("scipy"),
            "torch": _version("torch"),
            "oct-tissue-policy": _version("oct-tissue-policy"),
        },
        "torch_cuda_version": torch.version.cuda,
        "cuda_available": cuda_available,
        "cuda_device_count": torch.cuda.device_count() if cuda_available else 0,
        "cuda_devices": (
            [
                torch.cuda.get_device_name(index)
                for index in range(torch.cuda.device_count())
            ]
            if cuda_available
            else []
        ),
        "cudnn_version": torch.backends.cudnn.version() if cuda_available else None,
    }
