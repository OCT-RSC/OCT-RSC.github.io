from __future__ import annotations

"""Evaluate released and retrained checkpoints on one common validation set."""

import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from tissue_ai_ui_bundle.policy_experiments.config import torch_load, write_json_atomic
from tissue_ai_ui_bundle.policy_experiments.data import (
    PolicyDataset,
    collate_policy_samples,
    validate_split_payload,
)
from tissue_ai_ui_bundle.policy_experiments.engine import evaluate_model
from tissue_ai_ui_bundle.policy_experiments.models import build_policy

from .workflow import PreparedDataset


IDENTITY_FIELDS = (
    "material",
    "representation",
    "use_residual",
    "head",
    "sparse_backend",
    "sparse_backend_version",
    "observation_window",
    "prediction_window",
    "execute_window",
    "dense_resolution",
    "sparse_resolution",
    "point_count",
    "target_representation_source",
    "tissue_threshold",
    "air_sigma_multiplier",
    "maximum_visible_tissue_depth_mm",
    "mask_top_margin",
    "mask_bottom_margin",
    "mask_gap_fill_voxels",
    "minimum_visible_tissue_depth_voxels",
    "embedding_dim",
    "spatial_grid",
    "transformer_layers",
    "attention_heads",
    "feedforward_dim",
    "diffusion_steps",
    "inference_steps",
    "action_scale",
    "tool_scale",
)


def _evaluate(
    checkpoint: Path, prepared: PreparedDataset, device: torch.device
) -> dict:
    saved = torch_load(checkpoint, map_location="cpu")
    if saved.get("evaluation_weights") != "ema":
        raise ValueError(
            f"Checkpoint does not declare EMA evaluation weights: {checkpoint}"
        )
    config = saved["config"]
    split = json.loads(prepared.split.read_text(encoding="utf-8"))
    validate_split_payload(split)
    dataset = PolicyDataset(prepared.manifest, set(split["validation"]), config)
    loader = DataLoader(
        dataset,
        batch_size=int(config.get("validation_batch_size", 1)),
        shuffle=False,
        collate_fn=collate_policy_samples,
    )
    policy = build_policy(config).to(device).eval()
    load_result = policy.load_state_dict(saved["model_ema"], strict=True)
    if load_result.missing_keys or load_result.unexpected_keys:
        raise RuntimeError(
            "Strict state-dict loading unexpectedly returned key differences"
        )
    return {
        "checkpoint": str(checkpoint.resolve()),
        "checkpoint_config_digest": saved.get("config_digest"),
        "checkpoint_split_sha256": saved.get("split_sha256"),
        "checkpoint_cache_sha256": saved.get("cache_sha256"),
        "evaluated_split_sha256": split["split_sha256"],
        "evaluated_cache_sha256": dataset.cache_sha256,
        "config": {field: config.get(field) for field in IDENTITY_FIELDS},
        **evaluate_model(policy, config, loader, device),
    }


def compare_checkpoints(
    *,
    reference: str | Path,
    candidate: str | Path,
    prepared: str | Path,
    output: str | Path,
    device: str | None = None,
) -> dict:
    """Compare two EMA checkpoints on exactly the same prepared validation data."""

    selected_device = torch.device(
        device or ("cuda" if torch.cuda.is_available() else "cpu")
    )
    prepared_dataset = PreparedDataset.open(prepared)
    reference_result = _evaluate(
        Path(reference).expanduser().resolve(), prepared_dataset, selected_device
    )
    candidate_result = _evaluate(
        Path(candidate).expanduser().resolve(), prepared_dataset, selected_device
    )
    if reference_result["config"] != candidate_result["config"]:
        raise ValueError(
            "Reference and candidate checkpoints are different experiments"
        )

    metric_names = (
        "val_selection_score",
        "masked_horizon_normalized_mse",
        "first_action_translation_rmse_mm",
        "first_action_rotation_rmse_deg",
        "horizon_translation_rmse_mm",
        "horizon_rotation_rmse_deg",
    )
    result = {
        "schema": "oct_policy_checkpoint_comparison_v1",
        "device": str(selected_device),
        "evaluation_note": (
            "Both checkpoints were evaluated on the same current prepared cache. "
            "Original checkpoint cache hashes are provenance, not a requirement "
            "for this explicit cross-check."
        ),
        "reference": reference_result,
        "candidate": candidate_result,
        "candidate_minus_reference": {
            name: candidate_result[name] - reference_result[name]
            for name in metric_names
        },
    }
    write_json_atomic(Path(output), result)
    return result
