from __future__ import annotations

"""Fast contract and inference check for one prepared OCT sample."""

import json
from pathlib import Path

import numpy as np
import torch

from tissue_ai_ui_bundle.physical_policy.models import CosineSchedule
from tissue_ai_ui_bundle.policy_experiments.config import load_config, torch_load
from tissue_ai_ui_bundle.policy_experiments.data import (
    PolicyDataset,
    collate_policy_samples,
    validate_cache_files,
)
from tissue_ai_ui_bundle.policy_experiments.engine import move_batch
from tissue_ai_ui_bundle.policy_experiments.models import build_policy, predict_actions

from .experiments import resolve_experiment
from .workflow import PreparedDataset


def smoke_test(
    *,
    prepared: str | Path,
    experiment: str | Path | None = None,
    checkpoint: str | Path | None = None,
    device: str | None = None,
    diffusion_updates: int = 2,
    verify_all_cache_files: bool = False,
) -> dict:
    """Load one validation sample and verify the complete model input/output path."""

    prepared_dataset = PreparedDataset.open(prepared)
    saved: dict | None = None
    resolved_checkpoint: Path | None = None
    if checkpoint is not None:
        resolved_checkpoint = Path(checkpoint).expanduser().resolve()
        saved = torch_load(resolved_checkpoint, map_location="cpu")
        config = dict(saved["config"])
        if experiment is not None:
            selected = load_config(resolve_experiment(experiment))
            if selected["config_digest"] != saved.get("config_digest"):
                raise ValueError(
                    "Selected experiment does not match the checkpoint configuration"
                )
    elif experiment is not None:
        config = load_config(resolve_experiment(experiment))
    else:
        raise ValueError("Provide either checkpoint or experiment")
    split = json.loads(prepared_dataset.split.read_text(encoding="utf-8"))
    manifest = json.loads(prepared_dataset.manifest.read_text(encoding="utf-8"))
    if manifest["representation"] != config["representation"]:
        raise ValueError(
            "Prepared representation does not match the selected experiment: "
            f"{manifest['representation']!r} != {config['representation']!r}"
        )
    if manifest["material"] != config["material"]:
        raise ValueError("Prepared material does not match the selected experiment")
    if verify_all_cache_files:
        validate_cache_files(manifest, manifest_path=prepared_dataset.manifest)

    train = PolicyDataset(
        prepared_dataset.manifest, set(split["train"]), config,
    )
    validation = PolicyDataset(
        prepared_dataset.manifest, set(split["validation"]), config,
    )
    if not len(train) or not len(validation):
        raise RuntimeError("Smoke test requires at least one train and validation sample")

    runtime_device = torch.device(
        device or ("cuda" if torch.cuda.is_available() else "cpu")
    )
    policy = build_policy(config).to(runtime_device).eval()
    checkpoint_status = "random_initialization"
    checkpoint_path: str | None = None
    if saved is not None and resolved_checkpoint is not None:
        weights_key = (
            "model_ema"
            if saved.get("evaluation_weights", "ema") == "ema"
            else "model_raw"
        )
        incompatible = policy.load_state_dict(saved[weights_key], strict=True)
        if incompatible.missing_keys or incompatible.unexpected_keys:
            raise RuntimeError("Checkpoint failed strict state-dict loading")
        checkpoint_status = "strict_load_pass"
        checkpoint_path = str(resolved_checkpoint)

    batch = move_batch(
        collate_policy_samples([validation[0]]), runtime_device,
    )
    schedule = (
        CosineSchedule(int(config["diffusion_steps"]), runtime_device)
        if config["head"] == "diffusion"
        else None
    )
    generator = torch.Generator(device=runtime_device).manual_seed(
        int(config["inference_seed"])
    )
    updates = (
        min(int(diffusion_updates), int(config["diffusion_steps"]))
        if config["head"] == "diffusion"
        else int(config["inference_steps"])
    )
    with torch.inference_mode():
        prediction = predict_actions(
            policy, schedule, batch, updates, generator,
        )

    expected = (1, int(config["prediction_window"]), 6)
    if tuple(prediction.shape) != expected or not torch.isfinite(prediction).all():
        raise RuntimeError(
            f"Invalid prediction: shape={tuple(prediction.shape)}, "
            f"finite={bool(torch.isfinite(prediction).all())}"
        )
    physical = prediction[0].cpu().numpy() * np.asarray(
        config["action_scale"], dtype=np.float32,
    )
    return {
        "status": "pass",
        "device": str(runtime_device),
        "experiment": config["experiment_name"],
        "representation": config["representation"],
        "head": config["head"],
        "residual": bool(config["use_residual"]),
        "train_samples": len(train),
        "validation_samples": len(validation),
        "checkpoint": checkpoint_status,
        "checkpoint_path": checkpoint_path,
        "output_shape": list(prediction.shape),
        "first_action_6dof_mm_deg": physical[0].tolist(),
    }
