from __future__ import annotations

"""Create compact EMA checkpoints for deployment and public release."""

import hashlib
from pathlib import Path, PureWindowsPath

import torch

from tissue_ai_ui_bundle.policy_experiments.config import (
    EXPERIMENT_SCHEMA,
    torch_load,
)
from tissue_ai_ui_bundle.policy_experiments.models import build_policy


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def export_inference_checkpoint(
    source: str | Path, output: str | Path
) -> dict:
    """Strip optimizer state while preserving the exact EMA policy weights."""

    source = Path(source).expanduser().resolve()
    output = Path(output).expanduser().resolve()
    if source == output:
        raise ValueError("Inference export must not overwrite its source checkpoint")
    saved = torch_load(source, map_location="cpu")
    if saved.get("schema") != EXPERIMENT_SCHEMA:
        raise ValueError(f"Expected checkpoint schema {EXPERIMENT_SCHEMA!r}")
    if saved.get("evaluation_weights") != "ema" or "model_ema" not in saved:
        raise ValueError("Inference export requires declared EMA evaluation weights")

    config = dict(saved["config"])
    if config.get("config_path"):
        config_path = str(config["config_path"])
        config["config_path"] = (
            PureWindowsPath(config_path).name
            if "\\" in config_path
            else Path(config_path).name
        )
    policy = build_policy(config)
    incompatible = policy.load_state_dict(saved["model_ema"], strict=True)
    if incompatible.missing_keys or incompatible.unexpected_keys:
        raise RuntimeError("EMA weights failed strict model loading")

    exported = {
        "schema": saved["schema"],
        "config": config,
        "config_digest": saved.get("config_digest"),
        "split_sha256": saved.get("split_sha256"),
        "cache_sha256": saved.get("cache_sha256"),
        "evaluation_weights": "ema",
        "objective": saved.get("objective"),
        "best_epoch": saved.get("best_epoch"),
        "best_score": saved.get("best_score"),
        "model_ema": saved["model_ema"],
        "export_format": "inference_only_ema_v1",
        "source_checkpoint_sha256": _sha256(source),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    torch.save(exported, temporary)
    temporary.replace(output)
    return {
        "output": str(output),
        "sha256": _sha256(output),
        "source_checkpoint_sha256": exported["source_checkpoint_sha256"],
        "experiment": config["experiment_name"],
        "parameter_count": sum(parameter.numel() for parameter in policy.parameters()),
        "bytes": output.stat().st_size,
    }
