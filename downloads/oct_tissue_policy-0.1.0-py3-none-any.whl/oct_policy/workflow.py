from __future__ import annotations

"""High-level, reproducible data-preparation and training workflows."""

from dataclasses import dataclass
import json
from pathlib import Path

from tissue_ai_ui_bundle.policy_experiments.config import (
    config_digest,
    load_config,
    write_json_atomic,
)
from tissue_ai_ui_bundle.policy_experiments.data import (
    audit_dataset,
    build_cache,
    create_frozen_split,
    validate_cache_manifest,
    validate_split_payload,
)
from tissue_ai_ui_bundle.policy_experiments.engine import (
    export_offline_predictions,
    train_experiment,
    validate_checkpoint,
)

from .experiments import resolve_data_profile, resolve_experiment, resolve_matrix
from .environment import environment_summary
from .checkpoint import export_inference_checkpoint


PREPARED_DATA_SCHEMA = "oct_policy_prepared_data_v1"
REPRODUCTION_SCHEMA = "oct_policy_reproduction_v1"
MATRIX_SCHEMA = "oct_policy_experiment_matrix_v1"
DATA_PROFILE_SCHEMA = "oct_policy_data_profile_v1"


@dataclass(frozen=True)
class PreparedDataset:
    """Files produced by one preprocessing run.

    Paths in ``prepared.json`` are relative to its directory, so a prepared
    dataset can be moved or unpacked on another machine without editing it.
    """

    root: Path
    audit: Path
    split: Path
    manifest: Path
    metadata: Path

    @classmethod
    def open(cls, directory: str | Path) -> "PreparedDataset":
        root = Path(directory).expanduser().resolve()
        metadata = root / "prepared.json"
        payload = json.loads(metadata.read_text(encoding="utf-8"))
        if payload.get("schema") != PREPARED_DATA_SCHEMA:
            raise ValueError(f"Expected prepared-data schema {PREPARED_DATA_SCHEMA!r}")

        def resolve(key: str) -> Path:
            value = Path(payload[key])
            return value if value.is_absolute() else (root / value).resolve()

        prepared = cls(
            root=root,
            audit=resolve("audit"),
            split=resolve("split"),
            manifest=resolve("manifest"),
            metadata=metadata,
        )
        for path in (prepared.audit, prepared.split, prepared.manifest):
            if not path.is_file():
                raise FileNotFoundError(f"Prepared-data file is missing: {path}")
        split = json.loads(prepared.split.read_text(encoding="utf-8"))
        manifest = json.loads(prepared.manifest.read_text(encoding="utf-8"))
        validate_split_payload(split)
        validate_cache_manifest(manifest)
        if manifest.get("split_sha256") != split["split_sha256"]:
            raise ValueError("Prepared cache and split hashes do not match")
        if payload.get("split_sha256") not in (None, split["split_sha256"]):
            raise ValueError("prepared.json records a different split hash")
        if payload.get("cache_sha256") not in (None, manifest["cache_sha256"]):
            raise ValueError("prepared.json records a different cache hash")
        if payload.get("material") not in (None, manifest.get("material")):
            raise ValueError("prepared.json records a different material")
        if payload.get("representation") not in (None, manifest.get("representation"),):
            raise ValueError("prepared.json records a different representation")
        return prepared


def _relative_to_root(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def prepare_dataset(
    *,
    data_root: str | Path,
    data_profile: str | Path,
    experiment: str | Path,
    output: str | Path,
    overwrite: bool = False,
) -> PreparedDataset:
    """Audit raw trajectories, freeze the split, and cache one representation."""

    data_root = Path(data_root).expanduser().resolve()
    data_profile = resolve_data_profile(data_profile)
    experiment_path = resolve_experiment(experiment)
    output = Path(output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)

    config = load_config(experiment_path)
    profile = json.loads(data_profile.read_text(encoding="utf-8"))
    if profile.get("schema") != DATA_PROFILE_SCHEMA:
        raise ValueError(f"Expected data-profile schema {DATA_PROFILE_SCHEMA!r}")
    try:
        prefixes = profile["include_prefixes"][config["material"]]
    except KeyError as error:
        raise ValueError(
            f"Data profile does not define {config['material']!r} prefixes"
        ) from error

    audit_path = output / "audit.json"
    split_path = output / "split.json"
    audit = audit_dataset(data_root, audit_path, include_prefixes=prefixes)
    if audit["error_count"]:
        raise RuntimeError(
            f"Dataset audit found {audit['error_count']} invalid trajectories; "
            f"see {audit_path}"
        )
    expected_trajectories = profile.get("expected_trajectory_counts", {}).get(
        config["material"]
    )
    if (
        expected_trajectories is not None
        and audit["trajectory_count"] != int(expected_trajectories)
    ):
        raise RuntimeError(
            f"Data profile {profile['name']!r} expects {expected_trajectories} "
            f"{config['material']} trajectories, but found {audit['trajectory_count']}; "
            f"see {audit_path}"
        )
    action_count = sum(int(item["steps"]) for item in audit["trajectories"])
    expected_actions = profile.get("expected_action_counts", {}).get(
        config["material"]
    )
    if expected_actions is not None and action_count != int(expected_actions):
        raise RuntimeError(
            f"Data profile {profile['name']!r} expects {expected_actions} actions, "
            f"but found {action_count}; see {audit_path}"
        )

    split = create_frozen_split(
        data_root,
        config["material"],
        split_path,
        validation_fraction=0.2,
        seed=int(config["split_seed"]),
        include_prefixes=prefixes,
    )
    expected_split = profile.get("expected_split_counts", {}).get(config["material"])
    if expected_split is not None:
        observed_split = {
            "train": len(split["train"]),
            "validation": len(split["validation"]),
        }
        normalized_expected = {
            "train": int(expected_split["train"]),
            "validation": int(expected_split["validation"]),
        }
        if observed_split != normalized_expected:
            raise RuntimeError(
                f"Frozen split for {profile['name']!r} is {observed_split}, "
                f"expected {normalized_expected}"
            )
    manifest_path = build_cache(
        data_root, split_path, config, output / "cache", overwrite=overwrite,
    )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    payload = {
        "schema": PREPARED_DATA_SCHEMA,
        "data_profile": profile["name"],
        "data_profile_digest": config_digest(profile),
        "action_regime": profile.get("action_regime"),
        "task": profile.get("task"),
        "experiment": config["experiment_name"],
        "material": config["material"],
        "representation": config["representation"],
        "config_digest": config["config_digest"],
        "split_sha256": split["split_sha256"],
        "cache_sha256": manifest["cache_sha256"],
        "audit": _relative_to_root(audit_path, output),
        "split": _relative_to_root(split_path, output),
        "manifest": _relative_to_root(manifest_path, output),
        "train_trajectories": len(split["train"]),
        "validation_trajectories": len(split["validation"]),
        "actions": action_count,
        "observations_including_initial": action_count + audit["trajectory_count"],
    }
    write_json_atomic(output / "prepared.json", payload)
    return PreparedDataset.open(output)


def reproduce_experiment(
    *,
    data_root: str | Path,
    data_profile: str | Path,
    experiment: str | Path,
    output: str | Path,
    overwrite_cache: bool = False,
    resume: bool = True,
    export_predictions: bool = True,
) -> dict:
    """Run preprocessing, training, validation, and offline inference."""

    output = Path(output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    write_json_atomic(output / "environment.json", environment_summary())
    experiment_path = resolve_experiment(experiment)
    config = load_config(experiment_path)
    prepared = prepare_dataset(
        data_root=data_root,
        data_profile=data_profile,
        experiment=experiment_path,
        output=output / "prepared",
        overwrite=overwrite_cache,
    )
    training_dir = output / "training"
    training = train_experiment(
        manifest_path=prepared.manifest,
        split_path=prepared.split,
        config=config,
        output=training_dir,
        resume=resume,
    )
    checkpoint = training_dir / "checkpoint_best.pt"
    inference_checkpoint = output / "checkpoint_inference.pt"
    checkpoint_export = export_inference_checkpoint(checkpoint, inference_checkpoint)
    validation_path = output / "validation.json"
    validation = validate_checkpoint(
        checkpoint, prepared.manifest, prepared.split, validation_path,
    )
    predictions_path = output / "offline_predictions.json"
    if export_predictions:
        export_offline_predictions(
            checkpoint, prepared.manifest, prepared.split, predictions_path,
        )

    prepared_metadata = json.loads(prepared.metadata.read_text(encoding="utf-8"))
    summary = {
        "schema": REPRODUCTION_SCHEMA,
        "status": "complete",
        "experiment": config["experiment_name"],
        "data_profile": prepared_metadata["data_profile"],
        "action_regime": prepared_metadata.get("action_regime"),
        "task": prepared_metadata.get("task"),
        "train_trajectories": prepared_metadata["train_trajectories"],
        "validation_trajectories": prepared_metadata["validation_trajectories"],
        "actions": prepared_metadata["actions"],
        "observations_including_initial": prepared_metadata[
            "observations_including_initial"
        ],
        "config_digest": config["config_digest"],
        "split_sha256": training["split_sha256"],
        "cache_sha256": training["cache_sha256"],
        "prepared": _relative_to_root(prepared.metadata, output),
        "checkpoint": _relative_to_root(checkpoint, output),
        "inference_checkpoint": _relative_to_root(inference_checkpoint, output),
        "inference_checkpoint_sha256": checkpoint_export["sha256"],
        "training_result": _relative_to_root(training_dir / "result.json", output),
        "validation": _relative_to_root(validation_path, output),
        "offline_predictions": (
            _relative_to_root(predictions_path, output) if export_predictions else None
        ),
        "environment": "environment.json",
        "epochs_completed": training["epochs_completed"],
        "best_epoch": training["best_epoch"],
        "training_samples": training["training_samples"],
        "validation_samples": training["validation_samples"],
        "validation_selection_score": validation["val_selection_score"],
        "first_action_translation_rmse_mm": validation[
            "first_action_translation_rmse_mm"
        ],
        "first_action_rotation_rmse_deg": validation["first_action_rotation_rmse_deg"],
        "horizon_translation_rmse_mm": validation["horizon_translation_rmse_mm"],
        "horizon_rotation_rmse_deg": validation["horizon_rotation_rmse_deg"],
    }
    write_json_atomic(output / "reproduction.json", summary)
    return summary


def reproduce_matrix(
    *,
    data_root: str | Path,
    data_profile: str | Path,
    matrix: str | Path,
    output: str | Path,
    overwrite_cache: bool = False,
    resume: bool = True,
    export_predictions: bool = True,
) -> dict:
    """Train every experiment in a matrix while sharing representation caches."""

    matrix_path = resolve_matrix(matrix)
    definition = json.loads(matrix_path.read_text(encoding="utf-8"))
    if definition.get("schema") != MATRIX_SCHEMA:
        raise ValueError(f"Expected matrix schema {MATRIX_SCHEMA!r}")
    experiment_names = list(definition.get("experiments", []))
    if not experiment_names:
        raise ValueError("Experiment matrix is empty")
    if len(experiment_names) != len(set(experiment_names)):
        raise ValueError("Experiment matrix contains duplicate experiment names")
    matrix_configs = [
        load_config(resolve_experiment(experiment_name))
        for experiment_name in experiment_names
    ]
    experiment_names = [config["experiment_name"] for config in matrix_configs]
    matrix_materials = {config["material"] for config in matrix_configs}
    if len(matrix_materials) != 1:
        raise ValueError(
            "One matrix run must contain experiments for exactly one material"
        )

    profile_definition = json.loads(
        resolve_data_profile(data_profile).read_text(encoding="utf-8")
    )
    if profile_definition.get("schema") != DATA_PROFILE_SCHEMA:
        raise ValueError(f"Expected data-profile schema {DATA_PROFILE_SCHEMA!r}")
    matrix_material = next(iter(matrix_materials))
    if matrix_material not in profile_definition.get("include_prefixes", {}):
        raise ValueError(
            f"Data profile does not define prefixes for {matrix_material!r}"
        )
    profile_digest = config_digest(profile_definition)
    output = Path(output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    write_json_atomic(output / "environment.json", environment_summary())
    prepared_by_representation: dict[str, PreparedDataset] = {}
    completed: list[dict] = []
    dataset_summary: dict[str, int] = {}

    for config in matrix_configs:
        experiment_name = config["experiment_name"]
        experiment_path = resolve_experiment(experiment_name)
        representation = config["representation"]
        if representation not in prepared_by_representation:
            prepared_dir = output / "prepared" / representation
            if (prepared_dir / "prepared.json").is_file() and not overwrite_cache:
                prepared = PreparedDataset.open(prepared_dir)
            else:
                prepared = prepare_dataset(
                    data_root=data_root,
                    data_profile=data_profile,
                    experiment=experiment_path,
                    output=prepared_dir,
                    overwrite=overwrite_cache,
                )
            prepared_metadata = json.loads(
                prepared.metadata.read_text(encoding="utf-8")
            )
            if prepared_metadata["representation"] != representation:
                raise ValueError(
                    f"Prepared cache is {prepared_metadata['representation']!r}, "
                    f"not {representation!r}"
                )
            if prepared_metadata["material"] != config["material"]:
                raise ValueError("Prepared cache material does not match the matrix")
            if prepared_metadata["data_profile"] != profile_definition["name"]:
                raise ValueError("Prepared cache came from a different data profile")
            if prepared_metadata["data_profile_digest"] != profile_digest:
                raise ValueError("Prepared cache data-profile content has changed")
            dataset_summary = {
                "train_trajectories": prepared_metadata["train_trajectories"],
                "validation_trajectories": prepared_metadata[
                    "validation_trajectories"
                ],
                "actions": prepared_metadata["actions"],
                "observations_including_initial": prepared_metadata[
                    "observations_including_initial"
                ],
            }
            prepared_by_representation[representation] = prepared

        prepared = prepared_by_representation[representation]
        run_dir = output / "experiments" / config["experiment_name"]
        training = train_experiment(
            manifest_path=prepared.manifest,
            split_path=prepared.split,
            config=config,
            output=run_dir,
            resume=resume,
        )
        checkpoint = run_dir / "checkpoint_best.pt"
        inference_checkpoint = run_dir / "checkpoint_inference.pt"
        checkpoint_export = export_inference_checkpoint(
            checkpoint, inference_checkpoint,
        )
        validation_path = run_dir / "validation.json"
        validation = validate_checkpoint(
            checkpoint, prepared.manifest, prepared.split, validation_path,
        )
        predictions_path = run_dir / "offline_predictions.json"
        if export_predictions:
            export_offline_predictions(
                checkpoint, prepared.manifest, prepared.split, predictions_path,
            )
        completed.append(
            {
                "experiment": config["experiment_name"],
                "representation": representation,
                "head": config["head"],
                "residual": bool(config["use_residual"]),
                "checkpoint": _relative_to_root(checkpoint, output),
                "inference_checkpoint": _relative_to_root(
                    inference_checkpoint, output,
                ),
                "inference_checkpoint_sha256": checkpoint_export["sha256"],
                "config_digest": config["config_digest"],
                "split_sha256": training["split_sha256"],
                "cache_sha256": training["cache_sha256"],
                "epochs_completed": training["epochs_completed"],
                "best_epoch": training["best_epoch"],
                "training_samples": training["training_samples"],
                "validation_samples": training["validation_samples"],
                "validation_selection_score": validation["val_selection_score"],
                "first_action_translation_rmse_mm": validation[
                    "first_action_translation_rmse_mm"
                ],
                "first_action_rotation_rmse_deg": validation[
                    "first_action_rotation_rmse_deg"
                ],
                "horizon_translation_rmse_mm": validation[
                    "horizon_translation_rmse_mm"
                ],
                "horizon_rotation_rmse_deg": validation["horizon_rotation_rmse_deg"],
            }
        )
        write_json_atomic(
            output / "matrix_results.json",
            {
                "schema": MATRIX_SCHEMA,
                "matrix": definition["name"],
                "data_profile": profile_definition["name"],
                "action_regime": profile_definition.get("action_regime"),
                "task": profile_definition.get("task"),
                **dataset_summary,
                "environment": "environment.json",
                "status": "running",
                "completed": completed,
                "remaining": experiment_names[len(completed) :],
            },
        )

    result = {
        "schema": MATRIX_SCHEMA,
        "matrix": definition["name"],
        "data_profile": profile_definition["name"],
        "action_regime": profile_definition.get("action_regime"),
        "task": profile_definition.get("task"),
        **dataset_summary,
        "environment": "environment.json",
        "status": "complete",
        "completed": completed,
        "remaining": [],
    }
    write_json_atomic(output / "matrix_results.json", result)
    return result
