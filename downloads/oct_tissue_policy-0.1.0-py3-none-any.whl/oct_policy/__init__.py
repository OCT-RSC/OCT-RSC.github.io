"""Public API for training and running OCT tissue-control policies.

Heavy PyTorch modules are imported only when an operation needs them. This
keeps commands such as ``oct-policy list`` responsive on login nodes.
"""

from .experiments import (
    available_data_profiles,
    available_experiments,
    available_matrices,
    describe_experiments,
    resolve_data_profile,
    resolve_experiment,
    resolve_matrix,
)

__all__ = [
    "PreparedDataset",
    "RolloutPolicy",
    "available_data_profiles",
    "available_experiments",
    "available_matrices",
    "compare_checkpoints",
    "describe_experiments",
    "export_inference_checkpoint",
    "load_policy",
    "prepare_dataset",
    "replay_rollout",
    "reproduce_experiment",
    "reproduce_matrix",
    "smoke_test",
    "resolve_data_profile",
    "resolve_experiment",
    "resolve_matrix",
]


def __getattr__(name: str):
    """Lazily expose classes that otherwise import the PyTorch runtime."""

    if name == "RolloutPolicy":
        from .api import RolloutPolicy

        return RolloutPolicy
    if name == "PreparedDataset":
        from .workflow import PreparedDataset

        return PreparedDataset
    raise AttributeError(name)


def load_policy(*args, **kwargs):
    from .api import load_policy as implementation

    return implementation(*args, **kwargs)


def prepare_dataset(*args, **kwargs):
    from .workflow import prepare_dataset as implementation

    return implementation(*args, **kwargs)


def reproduce_experiment(*args, **kwargs):
    from .workflow import reproduce_experiment as implementation

    return implementation(*args, **kwargs)


def reproduce_matrix(*args, **kwargs):
    from .workflow import reproduce_matrix as implementation

    return implementation(*args, **kwargs)


def replay_rollout(*args, **kwargs):
    from .inference import replay_rollout as implementation

    return implementation(*args, **kwargs)


def compare_checkpoints(*args, **kwargs):
    from .comparison import compare_checkpoints as implementation

    return implementation(*args, **kwargs)


def export_inference_checkpoint(*args, **kwargs):
    from .checkpoint import export_inference_checkpoint as implementation

    return implementation(*args, **kwargs)


def smoke_test(*args, **kwargs):
    from .smoke import smoke_test as implementation

    return implementation(*args, **kwargs)
