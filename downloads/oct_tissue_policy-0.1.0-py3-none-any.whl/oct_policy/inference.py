from __future__ import annotations

"""File-based closed-loop inference helpers."""

import json
from pathlib import Path

import numpy as np

from .api import load_policy


def _input_path(value: str | Path, directory: Path) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (directory / path).resolve()


def load_tooltip_pose(
    value: str | Path | list, directory: str | Path | None = None
) -> np.ndarray:
    """Load one 4-by-4 transform from a nested list or ``.npy`` file."""

    if isinstance(value, (str, Path)):
        base = Path(directory).resolve() if directory is not None else Path.cwd()
        pose = np.asarray(np.load(_input_path(value, base)), dtype=np.float64)
    else:
        pose = np.asarray(value, dtype=np.float64)
    if pose.shape != (4, 4):
        raise ValueError(f"Expected a 4x4 tooltip pose, got {pose.shape}")
    return pose


def replay_rollout(
    *,
    checkpoint: str | Path,
    rollout: str | Path,
    output: str | Path,
    device: str | None = None,
) -> dict:
    """Predict actions for an ordered sequence of saved OCT scans.

    The JSON rollout specification contains a fixed target and initial pose,
    followed by scan/pose pairs. No robot command is sent by this function.
    """

    rollout_path = Path(rollout).expanduser().resolve()
    rollout_directory = rollout_path.parent
    specification = json.loads(rollout_path.read_text(encoding="utf-8"))
    policy = load_policy(checkpoint, device)
    policy.reset(
        _input_path(specification["target_volume"], rollout_directory),
        load_tooltip_pose(
            specification["initial_tooltip_pose"], directory=rollout_directory
        ),
    )

    predictions = []
    for index, step in enumerate(specification["steps"]):
        result = policy.step(
            _input_path(step["scan"], rollout_directory),
            load_tooltip_pose(step["tooltip_pose"], directory=rollout_directory),
        )
        predictions.append(
            {
                "step": index,
                **result,
                "action_6dof_mm_deg": result["action_6dof_mm_deg"].tolist(),
                "executed_action_sequence_6dof_mm_deg": result[
                    "executed_action_sequence_6dof_mm_deg"
                ].tolist(),
                "predicted_action_sequence_6dof_mm_deg": result[
                    "predicted_action_sequence_6dof_mm_deg"
                ].tolist(),
            }
        )

    payload = {
        "checkpoint": str(Path(checkpoint).expanduser().resolve()),
        "rollout": str(rollout_path),
        "steps": len(predictions),
        "predictions": predictions,
    }
    output = Path(output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload
