from __future__ import annotations

"""Small public inference API over the checkpoint-compatible implementation."""

from pathlib import Path

import torch

from tissue_ai_ui_bundle.policy_experiments.interface import UnifiedPolicyInterface


RolloutPolicy = UnifiedPolicyInterface


def load_policy(
    checkpoint: str | Path,
    device: str | None = None,
) -> RolloutPolicy:
    """Load a trained rollout policy using its saved model configuration."""
    selected_device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    return RolloutPolicy(Path(checkpoint), device=selected_device)

