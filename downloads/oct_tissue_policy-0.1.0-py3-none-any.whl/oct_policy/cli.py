from __future__ import annotations

"""Command-line interface for OCT policy reproduction and inference."""

import argparse
import json
from pathlib import Path

from .experiments import (
    available_data_profiles,
    available_matrices,
    describe_experiments,
    resolve_experiment,
)


def _add_experiment_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--experiment",
        required=True,
        help="Bundled experiment name or path to an experiment JSON file.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="oct-policy",
        description="Prepare OCT data, train a policy, and reproduce validation inference.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser(
        "list", help="List installed experiments, matrices, and data profiles."
    )
    list_parser.set_defaults(handler=_list_experiments)

    prepare = subparsers.add_parser(
        "prepare", help="Audit and preprocess raw demonstrations."
    )
    prepare.add_argument("--data-root", type=Path, required=True)
    prepare.add_argument("--data-profile", required=True)
    _add_experiment_argument(prepare)
    prepare.add_argument("--output", type=Path, required=True)
    prepare.add_argument("--overwrite", action="store_true")
    prepare.set_defaults(handler=_prepare)

    train = subparsers.add_parser("train", help="Train from a prepared dataset.")
    train.add_argument("--prepared", type=Path, required=True)
    _add_experiment_argument(train)
    train.add_argument("--output", type=Path, required=True)
    train.add_argument("--fresh", action="store_true")
    train.set_defaults(handler=_train)

    evaluate = subparsers.add_parser("evaluate", help="Evaluate a trained checkpoint.")
    evaluate.add_argument("--prepared", type=Path, required=True)
    evaluate.add_argument("--checkpoint", type=Path, required=True)
    evaluate.add_argument("--output", type=Path, required=True)
    evaluate.set_defaults(handler=_evaluate)

    infer = subparsers.add_parser(
        "infer", help="Run closed-loop-compatible inference on a saved scan sequence.",
    )
    infer.add_argument("--checkpoint", type=Path, required=True)
    infer.add_argument("--rollout", type=Path, required=True)
    infer.add_argument("--output", type=Path, required=True)
    infer.add_argument("--device", default=None)
    infer.set_defaults(handler=_infer)

    compare = subparsers.add_parser(
        "compare",
        help="Evaluate released and retrained checkpoints on the same validation data.",
    )
    compare.add_argument("--prepared", type=Path, required=True)
    compare.add_argument("--reference", type=Path, required=True)
    compare.add_argument("--candidate", type=Path, required=True)
    compare.add_argument("--output", type=Path, required=True)
    compare.add_argument("--device", default=None)
    compare.set_defaults(handler=_compare)

    export_checkpoint = subparsers.add_parser(
        "export-checkpoint",
        help="Create a compact strict-loadable EMA checkpoint for inference.",
    )
    export_checkpoint.add_argument("--input", type=Path, required=True)
    export_checkpoint.add_argument("--output", type=Path, required=True)
    export_checkpoint.set_defaults(handler=_export_checkpoint)

    smoke = subparsers.add_parser(
        "smoke",
        help="Verify one prepared sample, model contract, and optional checkpoint.",
    )
    smoke.add_argument("--prepared", type=Path, required=True)
    smoke.add_argument(
        "--experiment",
        help="Experiment name or JSON; optional when --checkpoint is provided.",
    )
    smoke.add_argument("--checkpoint", type=Path)
    smoke.add_argument("--device", default=None)
    smoke.add_argument("--diffusion-updates", type=int, default=2)
    smoke.add_argument("--verify-all-cache-files", action="store_true")
    smoke.set_defaults(handler=_smoke)

    reproduce = subparsers.add_parser(
        "reproduce",
        help="Run preprocessing, training, validation, and offline inference.",
    )
    reproduce.add_argument("--data-root", type=Path, required=True)
    reproduce.add_argument("--data-profile", required=True)
    _add_experiment_argument(reproduce)
    reproduce.add_argument("--output", type=Path, required=True)
    reproduce.add_argument("--overwrite-cache", action="store_true")
    reproduce.add_argument("--fresh", action="store_true")
    reproduce.add_argument("--skip-predictions", action="store_true")
    reproduce.set_defaults(handler=_reproduce)

    matrix = subparsers.add_parser(
        "matrix",
        help="Train a complete experiment matrix with shared preprocessing caches.",
    )
    matrix.add_argument("--data-root", type=Path, required=True)
    matrix.add_argument("--data-profile", required=True)
    matrix.add_argument("--matrix", type=Path, required=True)
    matrix.add_argument("--output", type=Path, required=True)
    matrix.add_argument("--overwrite-cache", action="store_true")
    matrix.add_argument("--fresh", action="store_true")
    matrix.add_argument("--skip-predictions", action="store_true")
    matrix.set_defaults(handler=_matrix)
    return parser


def _print(value: object) -> None:
    print(json.dumps(value, indent=2))


def _list_experiments(_: argparse.Namespace) -> None:
    _print(
        {
            "experiments": describe_experiments(),
            "matrices": list(available_matrices()),
            "data_profiles": list(available_data_profiles()),
        }
    )


def _prepare(args: argparse.Namespace) -> None:
    from .workflow import prepare_dataset

    prepared = prepare_dataset(
        data_root=args.data_root,
        data_profile=args.data_profile,
        experiment=args.experiment,
        output=args.output,
        overwrite=args.overwrite,
    )
    _print(json.loads(prepared.metadata.read_text(encoding="utf-8")))


def _train(args: argparse.Namespace) -> None:
    from tissue_ai_ui_bundle.policy_experiments.config import load_config
    from tissue_ai_ui_bundle.policy_experiments.engine import train_experiment

    from .workflow import PreparedDataset

    prepared = PreparedDataset.open(args.prepared)
    result = train_experiment(
        manifest_path=prepared.manifest,
        split_path=prepared.split,
        config=load_config(resolve_experiment(args.experiment)),
        output=args.output,
        resume=not args.fresh,
    )
    _print(result)


def _evaluate(args: argparse.Namespace) -> None:
    from tissue_ai_ui_bundle.policy_experiments.engine import validate_checkpoint

    from .workflow import PreparedDataset

    prepared = PreparedDataset.open(args.prepared)
    result = validate_checkpoint(
        args.checkpoint, prepared.manifest, prepared.split, args.output,
    )
    _print(result)


def _infer(args: argparse.Namespace) -> None:
    from .inference import replay_rollout

    result = replay_rollout(
        checkpoint=args.checkpoint,
        rollout=args.rollout,
        output=args.output,
        device=args.device,
    )
    _print({"steps": result["steps"], "output": str(args.output.resolve())})


def _compare(args: argparse.Namespace) -> None:
    from .comparison import compare_checkpoints

    result = compare_checkpoints(
        reference=args.reference,
        candidate=args.candidate,
        prepared=args.prepared,
        output=args.output,
        device=args.device,
    )
    _print(result["candidate_minus_reference"])


def _export_checkpoint(args: argparse.Namespace) -> None:
    from .checkpoint import export_inference_checkpoint

    _print(export_inference_checkpoint(args.input, args.output))


def _smoke(args: argparse.Namespace) -> None:
    from .smoke import smoke_test

    _print(
        smoke_test(
            prepared=args.prepared,
            experiment=args.experiment,
            checkpoint=args.checkpoint,
            device=args.device,
            diffusion_updates=args.diffusion_updates,
            verify_all_cache_files=args.verify_all_cache_files,
        )
    )


def _reproduce(args: argparse.Namespace) -> None:
    from .workflow import reproduce_experiment

    _print(
        reproduce_experiment(
            data_root=args.data_root,
            data_profile=args.data_profile,
            experiment=args.experiment,
            output=args.output,
            overwrite_cache=args.overwrite_cache,
            resume=not args.fresh,
            export_predictions=not args.skip_predictions,
        )
    )


def _matrix(args: argparse.Namespace) -> None:
    from .workflow import reproduce_matrix

    _print(
        reproduce_matrix(
            data_root=args.data_root,
            data_profile=args.data_profile,
            matrix=args.matrix,
            output=args.output,
            overwrite_cache=args.overwrite_cache,
            resume=not args.fresh,
            export_predictions=not args.skip_predictions,
        )
    )


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    args.handler(args)


if __name__ == "__main__":
    main()
